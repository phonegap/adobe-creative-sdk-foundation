/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/

#import <UIKit/UIKit.h>
#import "AdobeKulerClientInfo.h"

typedef void (^AdobeKulerSuccessBlockWithDictionary)( NSDictionary * dictResponse);
typedef void (^AdobeKulerErrorBlock)( NSError** error);
typedef void (^SuccessBlock)();

/**
 * To be documented
 */
@interface AdobeKulerSendReceiveBase : NSObject

//SignInToken and KulerAPI key
@property(strong, nonatomic) AdobeKulerClientInfo* kulerClientInfo;
@property(unsafe_unretained, nonatomic) BOOL isPublicRequest;


- (NSRange) matchString:(NSString *)string withRegularExpression:(NSString *)regularExpression;
- (NSRange) matchString:(NSString *)string withRegularExpression:(NSString *)regularExpression withOptions:(NSRegularExpressionOptions)options;
- (void) disposeRequest;

#pragma mark COMMON Calls.
- (void)settingCommonHeaderFields;

- (NSString *)addParametersToUri:(NSDictionary *)parametersDict webServiceEndPointMethod:(NSString *)webServiceEndPointMethod;

- (void)addHttpUserAgent;

- (BOOL) sendRequest:(NSString*) webServiceEndPointMethod
           viaMethod:(NSString*) method
       ofContentType:(NSString*) contentType
       andParameters:(NSDictionary*) parametersDict
andAddParamsToPostURL:(BOOL) addParamsToPostURL
    andPublicRequest:(BOOL)isPublicRequest
 withCompletionBlock:(void(^)(id response, NSInteger statusCode, NSError *error)) completionBlock;

- (void)connectionDidFinishLoading:(NSURLConnection *)connection;

- (void)requestTimeout;

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response;

- (void) connection: (NSURLConnection*) connection didFailWithError: (NSError*) error;

- (void) connection: (NSURLConnection*) connection didReceiveData: (NSData*) data;

@end


