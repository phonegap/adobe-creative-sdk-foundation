//
//  AdobeKulerPaletteViewController.h
//  AdobeKuler
//
//  Created by Wally Ho on 11/4/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdobeKulerClientInfo.h"
#import "AdobeKulerTheme.h"
#import "AdobeKulerThemes.h"
#import "AdobeKulerPaletteTableViewCell.h"
#import "AdobeKulerPaletteTableViewBaseViewController.h"

/**
 * To be documented
 */
@interface AdobeKulerPaletteViewController : AdobeKulerPaletteTableViewBaseViewController

@property (strong, nonatomic) IBOutlet UITapGestureRecognizer *tapGestureRecognizer;

typedef void (^KulerErrorComplete) (NSError* __autoreleasing *error);
typedef void (^KulerComplete) (AdobeKulerThemes* themes, AdobeKulerTheme* selectedTheme);
typedef void (^KulerThemesComplete) (AdobeKulerThemes* themes);

@property(unsafe_unretained, nonatomic) BOOL isPenTheSource;
@property(unsafe_unretained, nonatomic) BOOL isPenTheDeviceOwner;

@property(copy, nonatomic) void ( ^kulerCreativeCloudSignInCompletion)();
@property(copy, nonatomic) void ( ^kulerCreativeCloudSignUpCompletion)();

// This completion block needs to be set to sync to the pen CC.
@property(copy, nonatomic) KulerThemesComplete kulerSyncToCloudCompletion;
@property(copy, nonatomic) KulerThemesComplete kulerSyncFromCloudCompletion;

@property(copy, nonatomic) KulerComplete kulerCompletion;
@property(copy, nonatomic) KulerErrorComplete kulerErrorCompletion;
@property(copy, nonatomic) KulerThemesComplete kulerRandomThemesCompletion;
@property(copy, nonatomic) KulerThemesComplete kulerPopularThemesCompletion;
@property(copy, nonatomic) KulerThemesComplete kulerMyThemesCompletion;

@property(strong, nonatomic) AdobeKulerThemes* defaultThemes;
@property(strong, nonatomic) AdobeKulerThemes* ownedKulerThemes;

@property (weak, nonatomic) IBOutlet UIView *viewThemeAdditions;
@property (weak, nonatomic) IBOutlet UITextField *textFieldThemeAdditions;
@property (weak, nonatomic) IBOutlet UIView *viewFooter;
@property (strong, nonatomic) UIView *viewFooterView;
@property (weak, nonatomic) IBOutlet UIView *viewFooterInsideBorder;
@property (weak, nonatomic) IBOutlet UIView *viewFooterViewTopGreyLine;
@property (weak, nonatomic) IBOutlet UIView *viewNoThemesErrorScreens;

@property (strong, nonatomic) IBOutlet UIPanGestureRecognizer *panGestureRecognizer;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *barButtonItemRightButton;
- (void) setKulerClientInfo: (AdobeKulerClientInfo*) kulerClientInfo;
- (void)restoreDefaultsWhenEmpty;

@end
