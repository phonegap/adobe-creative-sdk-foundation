/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/

#import <UIKit/UIKit.h>
#import "AdobeKulerSendReceiveBase.h"
#import "AdobeKulerClientInfo.h"
#import "AdobeKulerThemes.h"
#import "UIColor+AdobeKulerColorUtils.h"

typedef void (^AdobeKulerSuccessBlockThemes)( AdobeKulerThemes * kulerThemes);


/**
 * To be documented
 */
@interface AdobeKulerEndpointModel : AdobeKulerSendReceiveBase
@property (unsafe_unretained, nonatomic) NSInteger imsEnvironment;


// Static that create its own instance of AdobeKulerSendRecieve
//query == GET
+ (void) queryThemesWithKulerClient:(AdobeKulerClientInfo*) kulerClientInfo
                   andPublicRequest:(BOOL) isPublicRequest
                      andParameters:(NSDictionary*) parametersDict
              withSuccessCompletion:(AdobeKulerSuccessBlockThemes) successComplete
                  onErrorCompletion:(AdobeKulerErrorBlock) errorComplete;

//search == GET
+ (void) searchThemesWithKulerClient:(AdobeKulerClientInfo*) kulerClientInfo
                    andPublicRequest:(BOOL) isPublicRequest
                       andParameters:(NSDictionary*) parametersDict
               withSuccessCompletion:(AdobeKulerSuccessBlockThemes) successComplete
                   onErrorCompletion:(AdobeKulerErrorBlock) errorComplete;


//query == PUT
+ (void) updateThemesWithKulerClient:(AdobeKulerClientInfo*) kulerClientInfo
                    andPublicRequest:(BOOL) isPublicRequest
                       andParameters:(NSDictionary*) parametersDict
               withSuccessCompletion:(AdobeKulerSuccessBlockWithDictionary) successComplete
                   onErrorCompletion:(AdobeKulerErrorBlock) errorComplete;


//create == POST
+ (void) createThemesWithKulerClient:(AdobeKulerClientInfo*) kulerClientInfo
                    andPublicRequest:(BOOL) isPublicRequest
                       andParameters:(NSDictionary*) parametersDict
               withSuccessCompletion:(AdobeKulerSuccessBlockWithDictionary) successComplete
                   onErrorCompletion:(AdobeKulerErrorBlock) errorComplete;

@end
