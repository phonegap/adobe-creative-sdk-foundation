//
//  AdobeKulerCommon.h
//  AdobeKuler
//
//  Created by Wally Ho on 12/10/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "AdobeKulerThemes.h"
#ifdef DEBUG
#define ADLog NSLog
#else
#define ADLog(...)
#endif
/**
 * To be documented
 */

@interface AdobeKulerCommon : NSObject
+ (AdobeKulerThemes *) getCombinedAdobeKulerThemes:(AdobeKulerThemes*) existingThemes
                                       andNewArray:(AdobeKulerThemes*) newThemes;
+ (AdobeKulerThemes *) removeAllDupsInAdobeKulerThemes:(AdobeKulerThemes*) themes;
+ (AdobeKulerThemes *) removeAllDuplicatesInAdobeKulerThemes:(AdobeKulerThemes*) themes;

+ (NSDictionary*) getCombinedArray:(NSArray*) oldArray andNewArray:(NSArray*) newArray;
+ (UIView*) findViewIn:(UIView*) view withClassName:(NSString*) className;
+ (UIImage*) fetchImageFromBundle:(NSString*) bundleName
              andContainingBundle:(NSBundle*) containingBundle
                   andNameOfImage:(NSString*) nameOfImage;
+ (UIImage *) getImageFromKulerResource:(NSString*)imageNamed;
@end
