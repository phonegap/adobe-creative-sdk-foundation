/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2014 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/

#import "AdobeCloudItem.h"

/**
 Folder items are fetched from the cloud in pages, so the field on which the items
 should be sorted as well as the sort direction must be specified when setting up
 this instance. If you need to change the sorting, you will need to create a new
 instance with the specified sort options.
 
 Once you have an AdobeCloudFolder instance set up, you can call hasNextPage and
 loadNextPage to start loading folder items from the cloud as needed.
 */

/**
 A utility to help determine if an AdobeCloudItem is an AdobeCloudFolder.
 */
#define IsAdobeCloudFolder(item) ( [item isKindOfClass: [AdobeCloudFolder class]] )

/**
 The sort options of the children in the folder.
 
 @deprecated Use AdobeCloudFolderOrderBy and AdobeCloudFolderOrderDirection.
 */
typedef NS_OPTIONS(NSUInteger, AdobeCloudFolderSortOptions) {
    /** No sorting specified. */
    AdobeCloudFolderSortUnset = 0,
    
    /** Sort ascending. */
    AdobeCloudFolderSortAscending = 1 << 0,
    
    /** Sort decending. */
    AdobeCloudFolderSortDescending = 1 << 1,
    
    /** Sort by folder name. */
    AdobeCloudFolderSortByName = 1 << 2,
    
    /** Sort by folder modified time. */
    AdobeCloudFolderSortByTime = 1 << 3
} __attribute__((deprecated));

/**
 AdobeCloudFolderOrderBy is an enumerated type that specifies the field key to
 sort on.
 */
typedef NS_ENUM(NSInteger, AdobeCloudFolderOrderBy) {
    /** Order folder items by name. */
    AdobeCloudFolderOrderByName,
    
    /** Order folder items by date modified. */
    AdobeCloudFolderOrderByModified,
};

/**
 AdobeCloudFolderOrderDirection is an enumerated type that specifies the ordering
 direction.
 */
typedef NS_ENUM(NSInteger, AdobeCloudFolderOrderDirection) {
    /** Order folder items in ascending order based on order type. */
    AdobeCloudFolderOrderAscending,
    
    /** Order folder items in descending order based on order type. */
    AdobeCloudFolderOrderDescending,
};

/**
 AdobeCloudFolder is the class that represents a folder on the Adobe Creative Cloud.
 */
@interface AdobeCloudFolder : AdobeCloudItem

/**
 Get the root folder of the logged in user.
 
 @returns the folder.
 */
+ (AdobeCloudFolder *)getRoot __attribute__((deprecated));

/**
 Get the root folder of the logged in user.
 
 @param field The field on which the items in the folder will be sorted (e.g., name, modification date).
 @param direction The direction (ascending or descending) in the the items will be sorted.
 @returns the folder.
 */
+ (AdobeCloudFolder *)getRootOrderedByField: (AdobeCloudFolderOrderBy)field
							 orderDirection: (AdobeCloudFolderOrderDirection)direction;

/**
 Get an AdobeCloudFolder based on the href.
 
 @param href The absolute HREF of the folder
 @param field The field on which the items in the folder will be sorted (e.g., name, modifiection date).
 @param direction The direction (ascending or descending) in the the items will be sorted.
 @returns the folder.
 */
+ (AdobeCloudFolder *)getFolderFromHref: (NSString *)href __attribute__((deprecated));

/**
 Get an AdobeCloudFolder based on the href for the logged in user.
 
 Folder items are fetched from the cloud in pages, so the field on which the items
 should be sorted as well as the sort direction must be specified when setting up
 this instance. If you need to change the sorting, you will need to create a new
 instance with the specified sort options.
 
 Once you have an AdobeCloudFolder instance set up, you can call hasNextPage and
 loadNextPage to start loading folder items from the cloud as needed.
 
 @param href The absolute HREF of the folder
 @param field The field on which the items in the folder will be sorted (e.g., name, modification date).
 @param direction The direction (ascending or descending) in the the items will be sorted.
@returns the folder.
 */
+ (AdobeCloudFolder *)getFolderFromHref: (NSString *)href
						   orderByField: (AdobeCloudFolderOrderBy)field
						 orderDirection: (AdobeCloudFolderOrderDirection)direction;

/**
 Create a new folder on the Adobe Creative Cloud asynchronously.

 @param name The name of the folder.
 @param folder The enclosing folder.
 @param completionBlock Optionally get an updated reference to the created folder when complete.
 @param errorBlock Optionally be notified of an error.
 */
+ (void)create: (NSString*)name
      inFolder: (AdobeCloudFolder *)folder
  onCompletion: (void (^)(AdobeCloudFolder* folder))completionBlock
       onError: (void (^)(NSError* error))errorBlock;

/**
 Delete a folder from the Adobe Creative Cloud asynchronously.
 
 @param completionBlock Optionally be notified when complete.
 @param errorBlock Optionally be notified of an error.
 */
- (void)delete: (void (^)(void))completionBlock
       onError: (void (^)(NSError* error))errorBlock;

/**
 Asynchronously get the children of the folder.
 
 @param sortOptions The sort order of the children (specify by bit-ORing the options).
 @param completionBlock An NSArray of AdobeCloudItems, and total number of items in the folder.
 @param errorBlock Optionally be notified of an error.
*/
- (void)getItems: (AdobeCloudFolderSortOptions)sortOptions
    onCompletion: (void (^)(AdobeCloudItemArray* items, NSUInteger totalItemsInFolder))completionBlock
         onError: (void (^)(NSError* error))errorBlock __attribute__((deprecated));

/**
 Indicates whether the cloud folder has another page of items that can be loaded.
 
 @returns true if the another page of items can be loaded; false otherwise.
 */
- (BOOL)hasNextPage;

/**
 Asynchronously gets the next page of items from the cloud folder. This should
 only be called if hasNextPage returns true. Behavior is undefined if hasNextPage
 returned false;
 
 @param pageSize The number of items to be fetched. This is just a hint. The actual number fetched may be more or less than this amount.
 @param completionBlock An NSArray of AdobeCloudItems, and total number of items retrieved.
 @param errorBlock Optionally be notified of an error.
 */
- (void)getNextPage: (NSUInteger)pageSize
	   onCompletion: (void (^)(AdobeCloudItemArray* items, NSUInteger totalItemsInFolder))completionBlock
			onError: (void (^)(NSError* error))errorBlock;

/**
 Resets the page iterator so that any subsequent call to hasNextPage will return
 true, and getNextPage will return the first page of cloud items. Keeps the current
 sorting options in effect.
 */
- (void)resetPaging;

/**
 Resets the page iterator so that any subsequent call to hasNextPage will return
 true, and getNextPage will return the first page of cloud items. Sets new sorting
 options for the cloud folder.
 
 @param field The field on which the items in the folder will be sorted (e.g., name, modification date).
 @param direction The direction (ascending or descending) in the the items will be sorted.
 */
- (void)resetPagingOrderedByField: (AdobeCloudFolderOrderBy)field
				   orderDirection: (AdobeCloudFolderOrderDirection)direction;

/**
 A utility to test the equlity of two AdobeCloudFolders.
 
 @param folder the AdobeCloudFolder to test against.
 */
- (BOOL)isEqualToFolder: (AdobeCloudFolder *)folder;

- (NSString *)description;

@end
