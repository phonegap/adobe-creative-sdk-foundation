/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#pragma once

#define INK_MIN_PRESSURE 0
#define INK_MAX_PRESSURE 2047

//NOTIFICATIONS

static NSString * const PenDidChangeConnectionStatus = @"AdobeDevicePenDidChangeConnectionStatus";
static NSString * const PenDidChangeBatteryLevel = @"AdobeDevicePenDidChangeBatteryLevel";
static NSString * const PenPalmRejectionChanged = @"AdobeDevicePenPalmRejectionChanged";

static NSString * const PenButton1Down = @"AdobeDevicePenButton1Down";
static NSString * const PenButton1Up = @"AdobeDevicePenButton1Up";
static NSString * const PenButton2Down = @"AdobeDevicePenButton2Down";
static NSString * const PenButton2Up = @"AdobeDevicePenButton2Up";

typedef NS_ENUM(NSUInteger, PenWritingStyle) {
    PenWritingStyleRightUp,
    PenWritingStyleRightMiddle,
    PenWritingStyleRightDown,
    PenWritingStyleLeftUp,
    PenWritingStyleLeftMiddle,
    PenWritingStyleLeftDown,
};