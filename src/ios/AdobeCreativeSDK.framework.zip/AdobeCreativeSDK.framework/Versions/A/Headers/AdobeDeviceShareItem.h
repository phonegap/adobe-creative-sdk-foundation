//
//  AXDShareItem.h
//  Adobe Line
//
//  Created by Greg on 2/10/14.
//  Copyright (c) 2014 Adobe Systems Incorporated. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 Share destination constant for an item that was posted to a Behance WIP.
 */
FOUNDATION_EXPORT NSString *const kAXDShareSheetBehanceWipDestination;

@interface AdobeDeviceShareItem : NSObject

/**
 The UIImage instance to be shared.
 */
@property (strong, nonatomic) UIImage *image;

/**
 The WIP id, if any, to append this image to. May be nil. Will be set to the final WIP id on successful posting.
 */
@property (strong, nonatomic) NSNumber *WipId;

/**
 If the final share destination is a Behance WIP, this is the revision ID for the share item.
 */
@property (readonly, nonatomic) NSNumber *revisionId;

/**
 Readonly access to the destination to which the item was shared. This will either be
 one of the UIActivity defined destination constants, or kAXDShareSheetBehanceWipDestination.
 This is set on completion of the share action, and may be nil if the share sheet was dismissed
 before any share action was completed.
 */
@property (readonly, nonatomic) NSString *sharedDesitination;

+ (AdobeDeviceShareItem *)shareItemForImage:(UIImage *)image wipId:(NSNumber *)wipId;

@end
