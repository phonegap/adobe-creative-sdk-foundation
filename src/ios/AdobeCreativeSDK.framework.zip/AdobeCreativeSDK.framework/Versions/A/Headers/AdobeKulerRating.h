//
//  AdobeKulerRating.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/29/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * To be documented
 */
@interface AdobeKulerRating : NSObject <NSCoding>
@property (strong, nonatomic) NSNumber* ratingOverall;
@property (strong, nonatomic) NSNumber* ratingUser;

-(NSDictionary*) dictionaryRepresentation;
+ (AdobeKulerRating *) objectFromDictionary:(NSDictionary *)dictResponse;
@end
