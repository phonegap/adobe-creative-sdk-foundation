/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "AdobeDeviceVectorShape.h"

@protocol AdobeDeviceSlideShapeDelegate <NSObject>

- (CGFloat)shapeLineThickness;
- (UIColor *)shapeLineColor;
- (UIColor *)shapeLineSnappedColor;
- (NSArray *)getOrientationSnapPoints;
- (NSArray *)getIntersectionBumpersForPath:(AdobeDeviceVectorPath *)path inView:(UIView *)view;
- (BOOL)toolShouldSnap;
- (BOOL)toolShouldBump;
- (CGFloat)bumperMagnetism;
- (CGFloat)bumperMaxSpeed;

- (CGFloat)smoothingMaxSpeed;

- (void)showSnapPoint:(CGPoint)snapPoint withColor:(UIColor *)color;
- (void)clearSnapPointsFromView;

@end


@interface AdobeDeviceSlideShape : UIView

@property (nonatomic, weak) id <AdobeDeviceSlideShapeDelegate> delegate;

@end


