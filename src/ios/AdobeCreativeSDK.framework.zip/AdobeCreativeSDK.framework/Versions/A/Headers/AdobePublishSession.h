/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/

#import "AdobePublishBaseModel.h"
#import "AdobePublishNetworkResponse.h"
#import "AdobePublishSession.h"

@class AdobePublishUser;

/**
 `AdobePublishSession` represents a logged in user session for the Behance API.
 */
@interface AdobePublishSession : AdobePublishBaseModel

/**
 Username of the logged in user represented by the session.
 */
@property (nonatomic, readonly) NSString *username;

/**
 User ID of the logged in user represented by the session.
 */
@property (nonatomic, readonly) NSNumber *userID;

/**
 Access token of the logged in user represented by the session.
 */
@property (nonatomic, readonly) NSString *accessToken;

/**
 User object containing full details for the logged in user represented by the session.
 */
@property (nonatomic, readonly) AdobePublishUser *user;


/**
 Session singleton.
 
 @return a newly-initialized `AdobePublishSession` object
 */
+ (AdobePublishSession *)sharedSession;

/**
 Check logged in status

 @return whether a logged-in session exists for the current user
 */
- (BOOL)isLoggedIn;

/**
 Convenience method for converting API login error message codes to human readable format.
 
 @param code error code received from the login endpoint
 
 @return human readable error message
 */
+ (NSString *)errorMessageForCode:(NSInteger)code;

@end
