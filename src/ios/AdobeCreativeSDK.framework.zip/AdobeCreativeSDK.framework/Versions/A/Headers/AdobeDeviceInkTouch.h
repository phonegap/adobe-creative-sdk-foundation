/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface AdobeDeviceInkTouch : NSObject

+(AdobeDeviceInkTouch *)penTouchFor:(UITouch *)touch;

/** 
 * Returns point location in input view.
 * @param view The view from which the touch occurs
 * @return The point of the touch within the input view
 */
-(CGPoint)locationInView:(UIView *)view;

/** 
 * Returns previous point location in input view.
 * @param view The view from which the touch occurs
 * @return The point of the previous touch within the input view
 */
-(CGPoint)previousLocationInView:(UIView *)view;

/** 
 * Syncs pressure value to specific JotTouch object.
 * @param pressure The current pressure value while the touch is being captured
 */
-(void)syncToTouchWithPressure:(NSUInteger)pressure;

/** 
 * The touch associated with this object.
 */
@property (nonatomic,readonly) UITouch* touch;

/** 
 * The pressure associated with the touch.
 */
@property (nonatomic,readwrite) NSUInteger pressure;

/** 
 * The point of the touch within the window.
 */
@property (nonatomic,readwrite) CGPoint windowPosition;

/** 
 * The previous point of the touch within the window.
 */
@property (nonatomic,readwrite) CGPoint previousWindowPosition;

/** 
 * The time at which the touch occurred.
 */
@property (nonatomic,readwrite) NSTimeInterval timestamp;

@end
