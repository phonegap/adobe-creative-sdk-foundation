/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

//  AdobePatentID="3106US02"

#import <Foundation/Foundation.h>
#import "AdobeDeviceSlideGestureRecognizer.h"
#import "AdobeDeviceVectorShape.h"

@protocol AdobeDeviceSlideDelegate;

/**
 * AdobeDeviceSlide represents the combined functionality of Adobe Slide. 
 * Any interactions of an Adobe Slide device with the iPad will be surfaced through AdobeDeviceSlide.
 * The typical use is to add AdobeDeviceSlide to your app using addSlideGestureToView:andPresentSlideInView:
 * The associated AdobeDeviceSlideGestureRecognizer will then track Adobe Slide on the touchscreen and report it's location
 * and oriention. Various methods and delegate callbacks are provided to improve the interaction of the slide gesture
 * with the other gestures in your app.
 * If the default slide view (ruler lines and other tracing shapes) is presented, then additional functionality can be
 * utilized during drawing operations with the "Tracing and Stamping" calls listed below.
 */

@interface AdobeDeviceSlide : NSObject
<UIGestureRecognizerDelegate>

/**
 The delegate of the slide object.
 */
@property (nonatomic, weak) id<AdobeDeviceSlideDelegate> delegate;

/**
 The gesture recognizer associated with the slide object responsible for tracking an Adobe Slide device on screen.
 */
@property (readonly, nonatomic) AdobeDeviceSlideGestureRecognizer *slideGesture;

/**
 The view within which Slide's tracing shapes are presented.
 */
@property (readonly, nonatomic) UIView *presentationView;

/**
 Set to YES to enable physical Adobe Slide button events. Set to NO for Adobe Slide button taps/holds to have no effect.
 */
@property (nonatomic) BOOL buttonEnabled;


#pragma mark - Setup

/**
 Adds the AdobeDeviceSlide gesture recognizer and (optionally) default view to the provided UIViews.
 Must be called before AdobeDeviceSlide will function.
 
 @param gestureView View to which the slide gesture recognizers should be added.
 @param presentationView View within which to present the default slide view, which displays tracing hint lines for the
 active shape. If nil, slide will present no UI and will not have any functionality beyond the gesture recognition.
 This will be set to the presentationView property of the AdobeDeviceSlide object.
 */
- (void)addSlideGestureToView:(UIView *)gestureView
        andPresentSlideInView:(UIView *)presentationView;

/**
 Remove any gesture recognizers and any default views that were placed using addSlideGestureToView:andPresentSlideInView:.
 Should be called before attempting to dealloc the views passed to addSlideGestureToView:andPresentSlideInView:.
 */
- (void)unregisterViews;

#pragma mark - Tracing and Stamping

/**
 Call this method at the start of a touch or gesture to be used for tracing along Slide's presented shape.
 This method sets important internal state and prepares Slide for tracing.
 Other trace calls may return nil or non-sensical values if this is not called first.
 
 @param drawingPoint The location of the start point of the drawings touch or gesture
 @param view The view within whose coordinate system drawingPoint is defined
 */
- (void)beginDrawingUsingSlideAtPoint:(CGPoint)drawingPoint inView:(UIView *)view;

/**
 Call this method at the end of a drawing touch or gesture that was used for tracing along Slide's presented shape.
 This method frees up Slide to move again and clears internal state relating to the last drawn stroke.
 */
- (void)endDrawingUsingSlide;

/**
 Returns the vector path object that is currently being traced on.
 Must be called between a beginDrawingUsingSlideAtPoint:inView: call and an endDrawingUsingSlide call, or will return nil.
 
 @return The AdobeDeviceVectorPath object that is currently being traced, defined in the coordinate system of the presentationView.
 */
- (AdobeDeviceVectorPath *)currentTracePath;

/**
 Returns a path object representing the traced portion of the currentTracePath between the given points
 
 @param fromPoint Point from which to start the returned subpath
 @param toPoint Point at which to end the returned subpath
 @return An AdobeDeviceVectorPath representing the subpath traced on the currentTracePath between the given points
 */
- (AdobeDeviceVectorPath *)pathTracedFromPoint:(CGPoint)fromPoint
                                       toPoint:(CGPoint)toPoint;

/**
 Returns a path object representing the portion of the currentTracePath beyond a given point
 
 @param fromPoint Point from which to start the returned subpath
 @param prevPoint A previous point. The direction on the currentTracePath from this point to the fromPoint 
                    defines the direction in which the returned path will extend.
 @return An AdobeDeviceVectorPath representing the subpath traced on the currentTracePath beyond the fromPoint
 */
- (AdobeDeviceVectorPath *)subPathOnTracedPathBeyondStartingPoint:(CGPoint)fromPoint
                                                withPreviousPoint:(CGPoint)prevPoint;

/**
 Returns the current shape, with transforms applied and defined in the given view.
 The returned shape might typically be used to stamp the entire shape into a drawing.
 
 @param view The UIView in whose coordinate system to define the returned shape
 @return And AdobeDeviceVectorShape representing the currently presented shape with transforms applied and defined in the given view
 */
- (AdobeDeviceVectorShape *)stampShapeInView:(UIView *)view;

/**
 Returns a boolean describing whether the current shape can be traced, or is a stamp only shape
 
 @return YES if the path can be traced and the path tracing methods will return valid results. NO if the shape is stamp only.
 */
- (BOOL)canTraceShape;

/**
 Checks the given point against certain criteria for which a drawings stroke should not begin.
 
 @param point Location of the touch point
 @param view View within whose coordinate system point is defined
 @return NO if the touch point location suggests that it is part of a Slide gesture and should not be used for drawing. Otherwise returns YES.
 */
- (BOOL)shouldBeginDrawingForPoint:(CGPoint)point inView:(UIView *)view;

/**
 Boolean describing whether or not the straight line tool is the currently active shape
 
 @return YES if the straight line tool is the currently active shape, otherwise NO
 */
- (BOOL)isUsingLineTool;

/**
 Switch the currently active shape to the straight line tool
 */
- (void)switchToLineTool;


#pragma mark - Gesture and Touch Interaction Methods

/**
 Asks Slide if a gesture recognizer should receive an object representing a touch.
 Call this method from within any of your own gestureRecognizer:shouldReceiveTouch: methods to check if a touch belongs
 to a Slide gesture and should be ignored.
 
 @param gestureRecognizer An instance of a subclass of the abstract base class UIGestureRecognizer.
 @param touch A UITouch object from the current multi-touch sequence.
 @return NO if the touch conflicts or belongs to a Slide gesture and should not be passed to the gestureRecognizer. Otherwise YES.
 */
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
       shouldReceiveTouch:(UITouch *)touch;

/**
 Asks Slide if a gesture recognizer should begin interpreting touches.
 Call this method from within any of your own gestureRecognizerShouldBegin: methods to check if a gesture conflicts
 with Slide and should be prevented from detecting.
 
 @param gestureRecognizer An instance of a subclass of the abstract base class UIGestureRecognizer.
 @return NO if the gesture conflicst with Slide and should be ignored. Otherwise YES.
 */
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer;

/**
 Returns a boolean describing whether the Adobe Slide physical button is being held.
 
 @return YES if the Adobe Slide physical button is being held. NO if it is not.
 */
- (BOOL)buttonHeld;

/**
 Used to cancel a potential Slide gesture recognition upon the successful detection of a potentially overlapping gesture.
 In particular, call this method on the detection of any two finger pan, pinch or long press gestures to prevent Slide from
 also detecting from those same touches.
 
 @param gestureRecognizer An instance of a subclass of the abstract base class UIGestureRecognizer for whose touches Slide should not detect.
 */
- (void)cancelSlideGestureForDetectedGestureRecognizer:(UIGestureRecognizer *)gestureRecognizer;

/**
 Used to check if a gesture recognizer's touches might also represent a Slide gesture and should therefore be ignored.
 
 @param An instance of a subclass of the abstract base class UIGestureRecognizer.
 @return YES if the gesture cannot also represent a Slide gesture, NO if the gestures overlap.
 */
- (BOOL)gestureRecognizerIsNotSlide:(UIGestureRecognizer *)gestureRecognizer;

@end



@protocol AdobeDeviceSlideDelegate <NSObject>

@optional

- (BOOL)adobeSlideShouldChangeActiveHandle:(AdobeDeviceSlide *)slide;

- (void)handleSlideGesture:(AdobeDeviceSlideGestureRecognizer *)slideGesture;

- (BOOL)slideGestureShouldBegin:(AdobeDeviceSlideGestureRecognizer *)slideGesture;

- (BOOL)slideGesture:(AdobeDeviceSlideGestureRecognizer *)slideGesture
shouldCancelGestureForPotentialDetection:(UIGestureRecognizer *)gestureRecognizer;

- (BOOL)slideGesture:(AdobeDeviceSlideGestureRecognizer *)slideGesture
shouldCancelGestureForConfirmedDetection:(UIGestureRecognizer *)gestureRecognizer;

- (void)adobeSlideBeganShapeResize:(AdobeDeviceSlide *)slide;


- (UIView *)viewForShapeStampingWithSlide:(AdobeDeviceSlide *)slide;

- (void)adobeSlide:(AdobeDeviceSlide *)slide
      stampedShape:(AdobeDeviceVectorShape *)shape
           atPoint:(CGPoint)point
            inView:(UIView *)view;

- (void)adobeSlideButtonTapped:(AdobeDeviceSlide *)slide;


- (CGFloat)shapeLineThicknessForSlide:(AdobeDeviceSlide *)slide;

- (UIColor *)shapeLineColorForSlide:(AdobeDeviceSlide *)slide;

- (UIColor *)shapeLineSnappedColorForSlide:(AdobeDeviceSlide *)slide;

- (BOOL)adobeSlideShouldSnapToAngles:(AdobeDeviceSlide *)slide;

- (NSUInteger)adobeSlideNumSnappingAngles:(AdobeDeviceSlide *)slide;

- (CGFloat)adobeSlideSnapAngleThreshold:(AdobeDeviceSlide *)slide;

@end
