//
//  AdobeKulerNavigationController.h
//  Kuler
//
//  Created by Wally Ho on 3/21/13.
//  Copyright (c) 2013 Adobe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdobeKulerTheme.h"
#import "AdobeKulerThemes.h"
#import "AdobeKulerClientInfo.h"
#import "AdobeKulerPaletteViewController.h"


/**
 * To be documented
 */
@interface AdobeKulerNavigationController : UINavigationController

- (void) setKulerClientInfo: (AdobeKulerClientInfo*) kulerClientInfo;

// This completion block needs to be set to continue when a color is selected.
// The entire list of kuler is sent as well as the selected color swatch.
- (void) setKulerCompletion:(KulerComplete) kulerCompletion;

// This completion block needs to be set to sync to the pen CC.
- (void) setKulerSyncToCloudCompletion:(KulerThemesComplete) kulerSyncToCloudCompletion;

// This completion block needs to be set to sync to the pen CC.
- (void) setKulerSyncFromCloudCompletion:(KulerThemesComplete) kulerSyncFromCloudCompletion;


// This completion block needs to be set to do something on error. Possibly retry.
- (void) setKulerErrorComplete:(KulerErrorComplete) kulerErrorCompletion;

// Set Default themes.
- (void) defaultThemesForKuler:(AdobeKulerThemes*) defaultThemes;

// Set My Themes themes.
- (void) setThemesForKuler:(AdobeKulerThemes*) themesForKuler;

// Is this the pen
@property (unsafe_unretained, nonatomic) BOOL isPenTheSource;
// Is this the owner.
@property (unsafe_unretained, nonatomic) BOOL isPenTheDeviceOwner;

// Set Sign In call.
- (void) setCreativeCloudSignInCompletion:(void(^)()) kulerCreativeCloudSignInCompletion;
// Notification: We also post the following notification if you do not choose to use the completion block
// One may setup a listener for the following
// Notification: "AdobeKulerCreativeCloudSign_In_Notification"

// Set Sign Up call.
- (void) setCreativeCloudSignUpCompletion:(void (^)()) kulerCreativeCloudSignUpCompletion;
// Notification: We also post the following notification if you do not choose to use the completion block
// One may setup a listener for the following
// Notification: "AdobeKulerCreativeCloudSign_Up_Notification"

// Set NavigationBar tint (what about a graphic?)
// If any part is nil the defaul will be used.
- (void) setNavigationBarColor:(UIColor*) tintColorForNavigationBar andFont:(UIFont*)font andFontTextColor:(UIColor*) fontTextColor;


// This completion block needs to be set to continue on when MyThemes is selected.
- (void) setKulerMyThemeCompletion:(KulerThemesComplete) kulerMyThemesCompletion;

// This completion block needs to be set to continue on when Popular is selected.
- (void) setKulerPopularThemeCompletion:(KulerThemesComplete) kulerPopularThemesCompletion;

// This completion block needs to be set to continue on when Popular is selected.
- (void) setKulerRandomThemeCompletion:(KulerThemesComplete) kulerRandomThemesCompletion;

@end
