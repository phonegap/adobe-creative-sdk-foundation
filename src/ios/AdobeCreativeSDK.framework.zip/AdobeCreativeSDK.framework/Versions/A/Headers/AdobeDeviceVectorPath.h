/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <Foundation/Foundation.h>
#import "AdobeDeviceVectorSegment.h"
#import "AdobeDeviceVectorSegmentBezierCurve.h"
#import "AdobeDeviceVectorSegmentLine.h"

typedef NS_ENUM(NSInteger, AdobeDeviceVectorDirection)
{
    /** Direction for descending AdobeDevicePathOffset values - moving from higher segmentIndex and t values to lower ones */
    AdobeDeviceVectorDirectionDescending = -1,
    /** No direction - returned when the start and end AdobeDevicePathOffsets are at the same location along the curve */
    AdobeDeviceVectorDirectionNone = 0,
    /** Direction for ascending AdobeDevicePathOffset values - moving from lower segmentIndex and t values to higher ones */
    AdobeDeviceVectorDirectionAscending = 1,
};

/**
 * An AdobeDeviceVectorPath element consists of a set of contiguous AdobeDeviceVectorSegment elements, 
 * and represents a single vector path. The path may be closed or open, but is always contiguous.
 */

@interface AdobeDeviceVectorPath : NSObject

/**
 The array of AdobeDeviceVectorSegment objects comprising the path. 
 The index of a segment in this array matches with the segmentIndex of any AdobeDevicePathOffsets described on the path.
 */
@property (nonatomic, readonly) NSArray *segments;

/**
 YES if the path is closed (end of the last segement equals the start of the first segment). NO if the path is open.
 */
@property (nonatomic, readonly) BOOL isClosedPath;

+ (AdobeDeviceVectorPath *)pathWithSegments:(NSArray *)segments
                              andClosedPath:(BOOL)isClosed;

/**
 Returns a subpath between the given path offsets. 
 For closed paths, the current path is traversed between the two offsets in the direction of shortest travel.
 
 @param startOffset Offset on the current path representing the start of the new path object.
 @param endOffset Offset on the current path representing the end of the new path object.
 @return A vector path object representing a copy of the current path between the given offsets
 */
- (AdobeDeviceVectorPath *)copyFromPathOffset:(AdobeDevicePathOffset)startOffset
                                 toPathOffset:(AdobeDevicePathOffset)endOffset;

/**
 Returns a subpath between the given path offsets, in the given direction
 
 @param startOffset Offset on the current path representing the start of the new path object.
 @param endOffset Offset on the current path representing the end of the new path object.
 @param direction Direction in which to traverse the path between the two offsets
 @return A vector path object representing a copy of the current path between the given offsets
 */
- (AdobeDeviceVectorPath *)copyFromPathOffset:(AdobeDevicePathOffset)startOffset
                                 toPathOffset:(AdobeDevicePathOffset)endOffset
                                  inDirection:(NSInteger)direction;

/**
 Returns a CGPoint located on the path at the given path offset.
 
 @param offset Path offset at which to calculate the CGPoint
 @return A CGPoint located on the path at the given path offset
 */
- (CGPoint)pointForPathOffset:(AdobeDevicePathOffset)offset;

/**
 Returns the direction on the path when moving from startOffset to endOffset. For closed paths, takes the shortest way around.
 
 @param startOffset Path offset defining the starting location of a motion along the path
 @param endOffset Path offset defining the end location of a motion along the path
 
 @return Direction traveled between the two given offsets
 */
- (AdobeDeviceVectorDirection)directionFromPathOffset:(AdobeDevicePathOffset)startOffset
                                         toPathOffset:(AdobeDevicePathOffset)endOffset;

/**
 Returns the closest AdobeDevicePathOffset on the path to the given point
 
 @param A CGPoint
 @return The closest AdobeDevicePathOffset on the path to the given point
 */
- (AdobeDevicePathOffset)closestPathOffestToPoint:(CGPoint)point;

/**
 * Returns an NSMutableData object who's bytes are a C array of CGPoints interpolated along the path.
 * The stride value can be used to add padding bytes between the CGPoints, which can be filled by the client app
 * with other data for use in, for example, an OpenGL vertex buffer.
 * T values are defined as the parametric location along the segment, ranging from 0 at the start of the segment
 * to 1 at the end.
 
 @param startOffset             The starting location along the path from which to begin interpolating.
 @param endOffset               The end location along the path at which to end interpolating.
 @param segmentLength           Spacing between interpolated points on the path.
 @param uniformityThreshold     Fractional error by which the actual distance between interpolated points can vary from segmentLength.
                                A smaller value is more accurate, but slower.
                                A larger value is faster, but may produce undesireable variations in interpolation spacing.
 @param previousPoint           A previous point from which to space the first interpolated point.
                                Typically used when interpolating a path in separate, contiguous sections.
 @param stride                  Number of bytes between the the start of each interpolated CGPoint in final data object.
 
 @return An NSMutableData object who's bytes are a C array of CGPoints interpolated along the path.
 */

- (NSMutableData *)interpolateFromPathOffset:(AdobeDevicePathOffset)startOffset
                                toPathOffset:(AdobeDevicePathOffset)endOffset
                           withSegmentLength:(CGFloat)segmentLength
                         uniformityThreshold:(CGFloat)uniformityThreshold
                               previousPoint:(CGPoint)previousPoint
                                      stride:(NSUInteger)stride;

@end
