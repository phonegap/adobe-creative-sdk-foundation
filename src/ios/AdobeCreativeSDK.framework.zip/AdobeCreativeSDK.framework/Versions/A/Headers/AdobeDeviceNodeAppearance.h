/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/**
 * This is the Node Button Appearance object. All of these properties are observed by the Node Button and will automatically be applied visualy when changed. All properties are animated between normal and selected states.
 *
 * You can use the Apple Appearance API to customize the look&feel of the Pen Tip Menu.
 You can read about iOS UIAppearance [here](http://nshipster.com/uiappearance/) and [here](http://useyourloaf.com/blog/2012/08/24/using-appearance-proxy-to-style-apps.html)
*/
@interface AdobeDeviceNodeAppearance : NSObject <UIAppearance>

+(NSArray*)appearanceProperties;

/**
 * Helper to create a new instance of `AdobeDeviceNodeAppearance` object.
 */
+(AdobeDeviceNodeAppearance *)create;

/**
 * Define the background color of the Node button.
 */
@property (nonatomic, readwrite) UIColor *backgroundColor UI_APPEARANCE_SELECTOR;

/**
 * Define the background color of the Node button when selected
 */
@property (nonatomic, readwrite) UIColor *selectedBackgroundColor UI_APPEARANCE_SELECTOR;

/**
 * Define the background color of the Node button when highlighted
 */
@property (nonatomic, readwrite) UIColor *highlightedBackgroundColor UI_APPEARANCE_SELECTOR;

/**
 * Define the icon of the Node button
 */
@property (nonatomic, readwrite) UIImage *icon UI_APPEARANCE_SELECTOR;

/**
 * Define the icon of the Node button when selected
 */
@property (nonatomic, readwrite) UIImage *selectedIcon UI_APPEARANCE_SELECTOR;

/**
 * Define the inner border color of the Node button
 */
@property (nonatomic, readwrite) UIColor *innerBorderColor UI_APPEARANCE_SELECTOR;

/**
 * Define the inner border color of the Node button when selected
 */
@property (nonatomic, readwrite) UIColor *selectedInnerBorderColor UI_APPEARANCE_SELECTOR;

/**
 * Define the inner border color of the Node button when highlighted
 */
@property (nonatomic, readwrite) UIColor *highlightedInnerBorderColor UI_APPEARANCE_SELECTOR;

/**
 * Define the inner border size of the Node button
 */
@property (nonatomic, readwrite) NSNumber *innerBorderSize UI_APPEARANCE_SELECTOR;

/**
 * Define the inner border size of the Node button when selected
 */
@property (nonatomic, readwrite) NSNumber *selectedInnerBorderSize UI_APPEARANCE_SELECTOR;

/**
 * Define the inner border size of the Node button when highlighted
 */
@property (nonatomic, readwrite) NSNumber *highlightedInnerBorderSize UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow color of the Node button
 */
@property (nonatomic, readwrite) UIColor *shadowColor UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow color of the Node button when selected
 */
@property (nonatomic, readwrite) UIColor *selectedShadowColor UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow color of the Node button when highlighted
 */
@property (nonatomic, readwrite) UIColor *highlightedShadowColor UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow thickness of the Node button
 */
@property (nonatomic, readwrite) NSNumber *shadowThickness UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow thickness of the Node button when selected
 */
@property (nonatomic, readwrite) NSNumber *selectedShadowThickness UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow thickness of the Node button when highlighted
 */
@property (nonatomic, readwrite) NSNumber *highlightedShadowThickness UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow radius of the Node button
 */
@property (nonatomic, readwrite) NSNumber *dropShadowRadius UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow radius of the Node button when selected
 */
@property (nonatomic, readwrite) NSNumber *selectedShadowRadius UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow radius of the Node button when highlighted
 */
@property (nonatomic, readwrite) NSNumber *highlightedShadowRadius UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow opacity of the Node button
 */
@property (nonatomic, readwrite) NSNumber *dropShadowOpacity UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow opacity of the Node button when selected
 */
@property (nonatomic, readwrite) NSNumber *selectedShadowOpacity UI_APPEARANCE_SELECTOR;

/**
 * Define the shadow opacity of the Node button when highlighted
 */
@property (nonatomic, readwrite) NSNumber *highlightedShadowOpacity UI_APPEARANCE_SELECTOR;

@end
