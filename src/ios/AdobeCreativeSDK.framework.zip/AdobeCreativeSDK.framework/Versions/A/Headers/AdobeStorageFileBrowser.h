/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 * THIS FILE IS PART OF THE CREATIVE SDK PUBLIC API
 *
 ******************************************************************************/

#import <Foundation/Foundation.h>

#import "AdobeCloudItem.h"

/**
 Startup option flags. These flags tell the file browser in which mode to start certain features.
 */
typedef NS_OPTIONS(NSUInteger, AdobeStorageFileBrowserOption) {
    EnableMultiSelect           = 1,        /** enable support for Multi-Select Mode */
    ShowMultiSelectOnPopup      = 1 << 1,   /** file browser should show Multi-Select mode by default */
    ShowGridViewOnPopup         = 1 << 2,   /** file browser should display grid view as the initial collection view */
    SortAlphabeticallyOnPopup   = 1 << 3    /** file browser should intially sort the collection alphabetically */
};

/**
 Bitmask field of startup option flags.
 */
typedef NSUInteger AdobeStorageFileBrowserOptions;

/**
 The filter list type. Either the items specified in the filter list are the types you 
 support (Inclusion) or the types you don't support (exclusion).
 */
typedef NS_ENUM( NSInteger, AdobeStorageFileBrowserFilterType )
{
    AdobeStorageFileBrowserFilterTypeUnspecified = 0,   /** the filter list is neither an inclusion nor exclusion list */
    AdobeStorageFileBrowserFilterTypeInclusion,         /** the filter list describes an inclusion list */
    AdobeStorageFileBrowserFilterTypeExclusion          /** the filter list describes an exclusion list */
};

#define AdobeStorageFileBrowserFilterWithBasicImages @[ kMimeTypeTIFF, kMimeTypeJPEG, kMimeTypeGIF, kMimeTypePNG, kMimeTypeBMP ]
#define AdobeStorageFileBrowserFilterWithAdobeContent @[ kMimeTypePhotoshop, kMimeTypeIllustrator ]

/**
 AdobeStorageFileBrowser is the class by which the Adobe Creative Cloud file browsing component is invoked.
 
 Currently it allows clients to browse for and select image files and have then supplied back as UIImage instances.  This functionality is temporary and is being supplied for early file browsing integration with the SDK.  In the future the file browsing component will return AdobeStorageFile instances which may be turned into UIImage instances upon request.
 */
@interface AdobeStorageFileBrowser : NSObject

/**
 Get the Adobe Storage File Browser singleton.
 
 @returns the singleton object.
 */
+ (AdobeStorageFileBrowser *)sharedBrowser;

/**
 Pops up a Creative Cloud file browsing component for selecting all Adobe Creative Cloud files.
 
 @param successBlock the code block called on successful selection of a set of items
 @param errorBlock the code block called on error completion
 @note we will attempt to popup the File Browser on the top most view controller
 */
- (void)popupFileBrowser: (void (^)(AdobeCloudItemArray *items))successBlock
                 onError: (void (^)(NSError *error))errorBlock;

/**
 Pops up a Creative Cloud file browsing component for selecting Image files.
 
 @param parent the parent view controller for the file browser user interface component
 @param exclusionList an array of NSStrings representing the mime types that should NOT be browsed for
 @param successBlock the code block called on successful selection of a set of items
 @param errorBlock the code block called on error completion
 */
- (void)popupFileBrowserWithParent: (UIViewController *)parent
                 withExclusionList: (NSArray *)exclusionList
                         onSuccess: (void (^)(AdobeCloudItemArray *items))successBlock
                           onError: (void (^)(NSError *error))errorBlock;

/**
 Pops up a Creative Cloud file browsing component for selecting filtered Adobe Creative Cloud files.
 
 @param parent the parent view controller for the file browser user interface component
 @param options a bitmask field of startup option flags
 @param filter an array of AdobeStorageConstant mime types that should be used for filtering.
        Specify nil for all types.
 @param filterType the FileBrowserFilterType which specifies how the filtering will behave.
 @param successBlock the code block called on successful selection of a set of items
 @param errorBlock the code block called on error completion
 */
- (void)popupFileBrowserWithParent: (UIViewController *)parent
                       withOptions: (AdobeStorageFileBrowserOptions) options
                        withFilter: (NSArray *)filter
                    withFilterType: (AdobeStorageFileBrowserFilterType)filterType
                         onSuccess: (void (^)(AdobeCloudItemArray *items))successBlock
                           onError: (void (^)(NSError *error))errorBlock;


@end
