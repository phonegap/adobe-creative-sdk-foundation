//
//  AdobeKulerThemeSave.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/14/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>
@class AdobeKulerThemeSaveHarmony;

/*
{
    "name" : "<Theme Name>",
    "harmony" : {
        "baseSwatchIndex" : 0-5,
        "rule" : "analogous|complimentary|monochromatic|triad|custom",
        "sourceURL" : "",
        "mood" : "colorful|bright|muted|dark|custom"
    },
    "iccProfile": "",
    "swatches" : [{
        "name": "<Swatch Name>",
        "mode" : "rgb|cmyk|lab|hsv",
        "values" : [0-1, 0-1]
    }, {
        
    }
                  ]
}*/

/**
 * To be documented
 */
@interface AdobeKulerThemeSave : NSObject
@property (copy, nonatomic) NSString* themeName;
@property (strong, nonatomic) NSDictionary*  harmonyAdobeKulerThemeSaveHarmony;
@property (copy, nonatomic) NSString* iccProfile;
@property (strong, nonatomic) NSArray*  swatcheDictionaries;

@end


/**
 * To be documented
 */
typedef NS_OPTIONS(NSInteger, AdobeKulerRule)
{
    /** to be documented */
    AdobeKulerRuleNone = 0,
    /** to be documented */
    AdobeKulerRuleAnalogous = 1 << 0,
    /** to be documented */
    AdobeKulerRuleComplimentary = 1 << 1,
    /** to be documented */
    AdobeKulerRuleMonochromatic = 1 << 2,
    /** to be documented */
    AdobeKulerRuleTriad = 1 << 3,
    /** to be documented */
    AdobeKulerRuleCustom = 1 << 4
};

/**
 * To be documented
 */
typedef NS_OPTIONS(NSInteger, AdobeKulerMood)
{
    /** to be documented */
    AdobeKulerMoodNone = 0,
    /** to be documented */
    AdobeKulerMoodColorful = 1 << 0,
    /** to be documented */
    AdobeKulerMoodBright = 1 << 1,
    /** to be documented */
    AdobeKulerMoodMuted = 1 << 2,
    /** to be documented */
    AdobeKulerMoodDark = 1 << 3,
    /** to be documented */
    AdobeKulerMoodCustom = 1 << 4
};

/**
 * To be documented
 */
@interface AdobeKulerThemeSaveHarmony : NSObject
@property (copy, nonatomic) NSString* baseSwatchIndex;
@property (unsafe_unretained, nonatomic) AdobeKulerRule rule; // AdobeKulerRuleAnalogous|AdobeKulerRuleComplimentary ...
@property (copy, nonatomic) NSString* sourceURL;
@property (unsafe_unretained, nonatomic) AdobeKulerMood mood;
@end



/**
 * To be documented
 */
typedef NS_OPTIONS(NSInteger, AdobeKulerMode)
{
    /** to be documented */
    AdobeKulerModeNone = 0,
    /** to be documented */
    AdobeKulerModergb = 1 << 0,
    /** to be documented */
    AdobeKulerModecmyk = 1 << 1,
    /** to be documented */
    AdobeKulerModelab = 1 << 2,
    /** to be documented */
    AdobeKulerModehsv = 1 << 3
};

@interface AdobeKulerThemeSaveSwatch : NSObject
@property (copy, nonatomic) NSString* swatchName;
@property (unsafe_unretained, nonatomic) AdobeKulerMode mode;
@property (copy, nonatomic) NSString* sourceURL;
@property (strong, nonatomic) NSDictionary* valuesWithArray;
@end
