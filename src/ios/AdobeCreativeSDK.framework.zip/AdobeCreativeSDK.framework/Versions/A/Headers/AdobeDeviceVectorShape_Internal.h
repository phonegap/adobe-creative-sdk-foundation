/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import "AdobeDeviceVectorShape.h"
#import "AdobeDeviceVectorPath_Internal.h"

@interface AdobeDeviceVectorShape ()

+ (AdobeDeviceVectorShape *)shapeForSVGString:(NSString *)string;

- (NSString *)SVGString;

+ (AdobeDeviceVectorShape *)shapeFromCoordFile:(NSString *)filePath;

+ (AdobeDeviceVectorShape *)shapeFromCoordString:(NSString *)coordString;

- (AdobeDeviceVectorShape *)copyWithTransform:(CGAffineTransform)transform;

- (void)addShapeToCGPath:(CGMutablePathRef)mPath;

- (CGPoint)pointOnPathIndex:(NSUInteger)pathIndex
                   atOffset:(AdobeDevicePathOffset)offset;

- (NSUInteger)indexForClosestPathToPoint:(CGPoint)point;

- (AdobeDevicePathOffset)closestPathOffsetOnPathIndex:(NSUInteger)pathIndex
                                          toPoint:(CGPoint)point;

- (NSInteger)directionOnPathIndex:(NSUInteger)pathIndex
                   fromPathOffset:(AdobeDevicePathOffset)startOffset
                     toPathOffset:(AdobeDevicePathOffset)endOffset;

- (AdobeDeviceVectorPath *)copyPathIndex:(NSUInteger)pathIndex
                          fromPathOffset:(AdobeDevicePathOffset)startOffset
                            toPathOffset:(AdobeDevicePathOffset)endOffset;

- (NSMutableData *)interpolatePathIndex:(NSUInteger)pathIndex
                         fromPathOffset:(AdobeDevicePathOffset)startOffset
                           toPathOffset:(AdobeDevicePathOffset)endOffset
                      withSegmentLength:(CGFloat)segmentLength
                    uniformityThreshold:(CGFloat)uniformityThreshold
                          previousPoint:(CGPoint)previousPoint
                                 stride:(NSUInteger)stride;

- (void)addIntersectionBumpersForSegment:(AdobeDeviceVectorSegment *)segment
                                 toArray:(NSMutableArray *)bumpers;

@end
