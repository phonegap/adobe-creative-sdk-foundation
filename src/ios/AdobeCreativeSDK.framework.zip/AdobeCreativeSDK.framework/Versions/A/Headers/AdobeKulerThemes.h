//
//  AdobeKulerThemes.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/29/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AdobeKulerTheme.h"

/**
 * To be documented
 */
@interface AdobeKulerThemes : NSObject <NSCoding>

@property (strong, nonatomic) AdobeKulerOwner* kulerThemesOwner;
@property (unsafe_unretained, nonatomic) NSInteger totalCount;
@property (strong, atomic) NSMutableArray* kulerthemesMutable;


- (void) addKulerThemeToEnd:(AdobeKulerTheme*) kulerTheme;
- (void) addKulerThemeAtHead:(AdobeKulerTheme*) kulerTheme;
- (void) deleteKulerTheme:(NSIndexPath*) indexPathToDelete;


- (NSDictionary*) dictionaryRepresentation;
+ (AdobeKulerThemes *) objectFromDictionary:(NSDictionary *)dictResponse;

@end
