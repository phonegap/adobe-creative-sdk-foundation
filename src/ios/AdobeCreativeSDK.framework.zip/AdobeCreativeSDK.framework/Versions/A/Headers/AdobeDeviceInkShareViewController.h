/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <UIKit/UIKit.h>
#import "AdobeDeviceInkContentViewControllerDelegate.h"
#import "AdobeDeviceShareItem.h"

/**
 * Built-in Share View Controller.
 *
 * This View Controller is an out of the box Sharing panel. It let you share content with AirDrop, Behance or Mail. 
 */

typedef void (^AdobeDeviceInkShareDismissHandler)(void);
typedef void (^AdobeDeviceInkShareCompletionHandler)(NSArray *sharedItems, BOOL completed, NSError *error);

@protocol AdobeDeviceInkShareDelegate;

@interface AdobeDeviceInkShareViewController : UIViewController <AdobeDeviceInkContentViewControllerDelegate>

/**
 Delegate for supplying data to the share sheet.
 */
@property (weak, nonatomic) id<AdobeDeviceInkShareDelegate> delegate;

/**
 Block called on the dismissal of the share sheet popover. If Get Feedback option is chosen, will be called after
 dismissal of the popover, but before the Behance WIP controller is called.
 */
@property (strong, nonatomic) AdobeDeviceInkShareDismissHandler dismissHandler;

/**
 Block called on the completion of the share sheet action, or when the share sheet is dismissed without 
 any share action.
 */
@property (strong, nonatomic) AdobeDeviceInkShareCompletionHandler completionHandler;

/**
 Array of UIActivity instances to be passed into the UIActivityViewController presented by the "More" button.
 */
@property (strong, nonatomic) NSArray *applicationActivities;

/**
 Array of UIActivityType strings for activities to be excluded from the UIActivityViewController presented by the "More" button.
 */
@property (strong, nonatomic) NSArray *excludedActivities;

/**
 Tint color for the icon images in the main share sheet. 
 Does not affect the UIActivityViewController presented by the "More" button.
 */
@property (strong, nonatomic) UIColor *iconTintColor;

/**
 Designated initializer for AdobeDeviceInkShareViewController.
 @param delegate Delegate object complying with the AdobeDeviceInkShareDelegate protocol.
 */
- (id)initWithDelegate:(id<AdobeDeviceInkShareDelegate>)delegate;

@end

@protocol AdobeDeviceInkShareDelegate <NSObject>

/**
 Delegate call used to request an array of AdobeDeviceShareItems for sharing with the share sheet.
 @param shareSheet The AdobeDeviceInkShareViewController instance making the call
 @return An NSArray of AdobeDeviceShareItems
 */
- (NSArray *)shareItemsForShareSheet:(AdobeDeviceInkShareViewController *)shareSheet;

/**
 Delegate call used to request the popover controller used to present the AdobeDeviceInkShareViewController. This is
 needed in order to present the system share sheet within the same popover.
 @param shareSheet The AdobeDeviceInkShareViewController instance making the call
 @return An instance of UIPopoverController
 */
- (UIPopoverController *)presentingPopoverControllerForShareSheet:(AdobeDeviceInkShareViewController *)shareSheet;

@end
