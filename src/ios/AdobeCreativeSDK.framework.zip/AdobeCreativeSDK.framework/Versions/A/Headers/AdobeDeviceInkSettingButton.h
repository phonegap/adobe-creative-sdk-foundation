/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <UIKit/UIKit.h>


/**
 * Use a Pen Setting view to present the user with a button that let the user access the pen settings. 
 * The Pen Setting Icon. reflect the current state of the pen connection. If the pen is connected, 
 * an icon representing a connected pen will be shown. When there isn't any pen connected, the icon will 
 * be representing no pen connected.
 * When the user press the button, he is automatically presented with the Mighty Settings Popover 
 * that let him connect to a Pen, setup and register his Pen etc. 
 * Use this class by embedding an instance of it in your view hierarchy following the experience guideline.
 */
@interface AdobeDeviceInkSettingButton : UIButton <UIPopoverControllerDelegate>


@property (nonatomic, strong) UIImage *penDisconnectedImage UI_APPEARANCE_SELECTOR;
@property (nonatomic, strong) UIImage *penDisconnectedHighlightImage UI_APPEARANCE_SELECTOR;
@property (nonatomic, strong) UIImage *penScanningImage UI_APPEARANCE_SELECTOR;
@property (nonatomic, strong) UIImage *penConnectedImage UI_APPEARANCE_SELECTOR;
@property (nonatomic, strong) UIImage *penConnectedHighlightImage UI_APPEARANCE_SELECTOR;

/**
 If YES, connection center hud messages are displayed next to button while connecting pen with button only.
 Default is NO.
 */
@property (nonatomic) BOOL showConnectingMessage;

/**
 Helper to create a new instance of `AdobeDeviceInkSettingButton`
 */
+(AdobeDeviceInkSettingButton *)create;

@end
