/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "AdobeDeviceInkConstants.h"
#import "AdobeDeviceNodeAppearance.h"
#import "AdobeDeviceInkMenuViewController.h"
#import "AdobeDeviceKulerViewController.h"
#import "AdobeDeviceClipboardViewController.h"
#import "AdobeDeviceInkShareViewController.h"
#import "AdobeDeviceInkSettingButton.h"
#import "AdobeDeviceInkPasteboard.h"
#import "AdobeDeviceInkPasteboardItem.h"
#import "AdobeDeviceInkManager.h"
#import "AdobeDeviceInk.h"
#import "AdobeDeviceInkTouch.h"
#import "AdobeDeviceInkManagerDelegate.h"
#import "AdobeDeviceInkTouchDelegate.h"
#import "AdobeDeviceClipboardDelegate.h"
#import "AdobeDeviceSlide.h"
#import "AdobeDeviceConnectionHUD.h"

typedef void (^CompletionBlock)();

/**
 * Centralized access to all AdobeDevice features
 */
@interface AdobeDevice : NSObject

/**
 * Read-only access to the Pen Manager.
 * @see AdobeDeviceInkManager
 */
@property (nonatomic,readonly) AdobeDeviceInkManager *penManager;

/**
 * Read-only access to the Mighty Pasteboard.
 * This class is responsible for the Copy/Paste manaagement.
 * In order for your app to work with the Mighty Copy/Paste workflow you must register an
 * AdobeDeviceInkPasteboardDelegate within the AdobeDeviceInkPasteboard.
 * @see AdobeDeviceInkPasteboard
 */
@property (nonatomic,readonly) AdobeDeviceInkPasteboard *pasteboard;

/**
 * Read-only access to the Pen Tip Menu View Controller. This Controller let you manage the 3 custom node buttons.
 * @see AdobeDeviceInkMenuViewController
 */
@property (nonatomic,readonly) AdobeDeviceInkMenuViewController *inkMenuController;

/**
 * Read-only access to the Kuler View Controller.
 * @see AdobeDeviceKulerViewController
 */
@property (nonatomic,readonly) AdobeDeviceKulerViewController *kulerViewController;

/**
 * Read-only access to the Creative Cloud Clipboard View Controller.
 * @see AdobeDeviceClipboardViewController
 */
@property (nonatomic,readonly) AdobeDeviceClipboardViewController *clipboardViewController;

/**
 * Read-only access to the Share View Controller.
 * @see AdobeDeviceInkShareViewController
 */
@property (nonatomic,readonly) AdobeDeviceInkShareViewController *shareViewController;

/**
 * Read-only access to Slide related features.
 * @see AdobeDeviceSlide
 */
@property (nonatomic,readonly) AdobeDeviceSlide *slide;

/**
 * Read-only property to know if the Ink Menu is currently displayed or not.
 */
@property (nonatomic,readonly,getter = isInkMenuVisible) BOOL inkMenuVisible;

/**
 * In order to initiate AdobeDevice, you must call this method.
 */
+ (void)start;

/**
 * In order to initiate AdobeDevice, you must call this method.
 * You can pass a specific UIWindow in case you want to initialize AdobeDevice with a particular Window instance.
 * @param window the window in which you want to initialize AdobeDevice
 */
+ (void)startWithWindow:(UIWindow*)window;

/**
 * Singleton to access AdobeDevice features
 */
+ (AdobeDevice *)sharedInstance;

/**
 * presentInkMenuAnimated:animated allows you to present the Pen Tip Menu.
 * @param animated let you animate the pen tip menu when appearing.
 */
- (void)presentInkMenuAnimated:(BOOL)animated;

/**
 * dismissInkMenuAnimated:animated allows you to dismiss the Pen Tip Menu.
 * @param animated let you animate the pen tip menu when disappearing.
 */
- (void)dismissInkMenuAnimated:(BOOL)animated;

/**
 * presentInkSetupAnimated:animated:completion presents the Mighty Setup dialog
 * allowing the user to setup their Mighty.
 * @param animated let you animate the pen tip menu when appearing.
 * @param completed the completion block to be called upon completion
 */
- (void)presentInkSetupAnimated:(BOOL)animated completion:(CompletionBlock)completed;

/**
 * dismissInkSetupAnimated:animated:completion dismissed the Mighty Setup popup.
 * @param animated let you animate the pen tip menu when disappearing.
 * @param completed the completion block to be called upon completion
 */
- (void)dismissInkSetupAnimated:(BOOL)animated completion:(CompletionBlock)completed;



@end
