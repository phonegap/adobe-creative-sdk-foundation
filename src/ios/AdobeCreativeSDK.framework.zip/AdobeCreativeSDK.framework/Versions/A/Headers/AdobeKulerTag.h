//
//  AdobeKulerTag.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/29/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * To be documented
 */
@interface AdobeKulerTag : NSObject <NSCoding>
@property (unsafe_unretained, nonatomic) NSInteger tagId;
@property (strong, nonatomic) NSArray* tagArray;

-(NSDictionary*) dictionaryRepresentation;
+ (AdobeKulerTag *) objectFromDictionary:(NSDictionary *)dictResponse;
@end
