/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/

/**
 `AdobePublishNetworkResponse` encapsulates a network response from the Behance API.
 */

#import <Foundation/Foundation.h>

@interface AdobePublishNetworkResponse : NSObject

/**
 Flag identifying whether the network request was successful or not.
 */
@property (nonatomic, readonly, getter = isSuccessful) BOOL successful;

/**
 Response object returned from the network request. Typically an `NSDictionary` of JSON data.
 */
@property (nonatomic, strong, readonly) id responseObject;

/**
 Error returned from the request, if any.
 */
@property (nonatomic, strong, readonly) NSError *error;

/**
 Response object returned from the network request. Typically a single `AdobePublishBaseModel` subclass object, or an array containing `AdobePublishBaseModel` subclass objects.
 */
@property (nonatomic, strong, readonly) id result;

/**
 Date that the network response was received.
 */
- (NSDate *)responseDate;

@end

typedef void(^AdobePublishNetworkResponseCompletion)(AdobePublishNetworkResponse *response);
typedef void(^AdobePublishNetworkResponseProgress)(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpected);
