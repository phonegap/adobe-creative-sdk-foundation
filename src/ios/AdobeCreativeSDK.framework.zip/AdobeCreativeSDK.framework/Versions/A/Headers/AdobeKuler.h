//
//  AdobeKuler.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/14/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#ifdef FRAMEWORK

#ifndef ADOBEKULER_H_
#define ADOBEKULER_H_
#import <AdobeKuler-iOS/AdobeKulerCommon.h>
#import <AdobeKuler-iOS/AdobeKulerPaletteViewController.h>
#import <AdobeKuler-iOS/AdobeKulerNavigationController.h>
#import <AdobeKuler-iOS/AdobeKulerThemes.h>
#import <AdobeKuler-iOS/AdobeKulerTheme.h>
#import <AdobeKuler-iOS/AdobeKulerSwatches.h>
#import <AdobeKuler-iOS/AdobeKulerHarmony.h>
#import <AdobeKuler-iOS/AdobeKulerTag.h>
#import <AdobeKuler-iOS/AdobeKulerRating.h>
#import <AdobeKuler-iOS/AdobeKulerComment.h>
#import <AdobeKuler-iOS/AdobeKulerAuthor.h>
#import <AdobeKuler-iOS/AdobeKulerClientInfo.h>
#import <AdobeKuler-iOS/AdobeKulerThemeSave.h>
#import <AdobeKuler-iOS/AdobeKulerEndpointModel.h>
#import <AdobeKuler-iOS/UIColor+AdobeKulerColorUtils.h>
#import <AdobeKuler-iOS/AdobeKulerPaletteTableViewCell.h>
#import <AdobeKuler-iOS/AdobeKulerPaletteTableViewBaseViewController.h>

#endif	/* ADOBEKULER_H_ */

#else

#import "AdobeKulerCommon.h"
#import "AdobeKulerPaletteViewController.h"
#import "AdobeKulerNavigationController.h"
#import "AdobeKulerThemes.h"
#import "AdobeKulerTheme.h"
#import "AdobeKulerSwatches.h"
#import "AdobeKulerHarmony.h"
#import "AdobeKulerTag.h"
#import "AdobeKulerRating.h"
#import "AdobeKulerComment.h"
#import "AdobeKulerAuthor.h"
#import "AdobeKulerClientInfo.h"
#import "AdobeKulerThemeSave.h"
#import "AdobeKulerEndpointModel.h"
#import "UIColor+AdobeKulerColorUtils.h"
#import "AdobeKulerPaletteTableViewCell.h"
#import "AdobeKulerPaletteTableViewBaseViewController.h"

#endif

@interface AdobeKuler: NSObject

+ (id) factoryInitialKulerNavigationController;


@end
