/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/

#import <Foundation/Foundation.h>

@interface AdobeCreativeSDKVersion : NSObject

/**
 Get the major.minor version (e.g., 1.0, 2.0, etc.) of the Adobe Creative SDK framework.
 
 @return the major.minor version
 */
+ (NSString *)majorMinorVersion;

/**
 Get the build number (e.g., 3124) of the Adobe Creative SDK framework.
 
 @return the build number
 */
+ (NSString *)buildNumber;

/**
 Get the full version: major.minor.buildNumber (e.g., 1.0.3124).
 
 @return the full version
 */
+ (NSString *)version;

@end
