/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2014 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/

#import "AdobeCloudItem.h"

#import <AssetsLibrary/AssetsLibrary.h>
#import <UIKit/UIKit.h>

/**
 A utility to help determine if an AdobeCloudItem is an AdobeCloudFile.
 */
#define IsAdobeCloudFile(item) ( [item isKindOfClass: [AdobeCloudFile class]] )

/**
 The content-types in which to request a rendition.
 */
typedef NS_ENUM( NSInteger, AdobeCloudFileRenditionType )
{
    /** The JPEG file type on the Creative Cloud */
    AdobeCloudFileRenditionTypeJPEG = 0,

    /** The PNG file type on the Creative Cloud */
    AdobeCloudFileRenditionTypePNG,
    
    /** The PDF file type on the Creative Cloud */
    AdobeCloudFileRenditionTypePDF
};

#define FULL_SIZE_RENDITION CGSizeZero
#define THUMBNAIL_SIZED_RENDITION CGSizeMake( 250, 0 )

@class AdobeCloudFolder;

/**
 AdobeCloudFile is the class that represents a file on the Adobe Creative Cloud.
 */
@interface AdobeCloudFile : AdobeCloudItem

/**
 The content type of the file.
 @returns the content type.
 */
@property (readonly, nonatomic, strong) NSString* type;

/**
 The MD5 hash of the file.
 @returns the hash.
 */
@property (readonly, nonatomic, strong) NSString* md5Hash;

/**
 The file size in bytes.
 @returns the file size.
 */
@property (readonly, nonatomic, unsafe_unretained) long long fileSize;

/**
 The current version number this file represents.
 @returns the version number.
 */
@property (readonly, nonatomic, unsafe_unretained) NSUInteger currentVersion;

/**
 Optional metadata for the file. For example, if the file is an image, the width and height
 be specified here.
 @returns optional metadata.
 */
@property (readonly, nonatomic, strong) NSDictionary* optionalMetadata;

/**
 Create and upload a file onto the Adobe Creative Cloud asynchronously.
 
 @param name The name of the file.
 @param parentFolder The enclosing folder of the file.
 @param dataPath The local URL that stores the data for the file.
 @param type The content-type of the file.
 @param progressBlock Optionally track the upload progress.
 @param completionBlock Optionally get an updated reference to the created file when complete.
 @param cancellationBlock Optionally be notified of a cancellation on upload.
 @param errorBlock Optionally be notified of an error.
 
 @returns A placeholder pointer to the AdobeCloudFile.
 */
+ (AdobeCloudFile *)create: (NSString*)name
                  inFolder: (AdobeCloudFolder *)parentFolder
              withDataPath: (NSURL*)dataPath
                  withType: (NSString*)type
                onProgress: (void (^)(double fractionCompleted))progressBlock
              onCompletion: (void (^)(AdobeCloudFile* file))completionBlock
            onCancellation: (void (^)(void))cancellationBlock
                   onError: (void (^)(NSError* error))errorBlock;

/**
 Cancel the creation request.
 */
- (void)cancelCreationRequest;

/**
 Change the priority of the upload. By default: NSOperationQueuePriorityNormal.
 
 @param priority The priority of the request.
 */
- (void)changeCreationRequestPriority:(NSOperationQueuePriority)priority;

/**
 Update a file onto the Adobe Creative Cloud asynchronously.
 
 @param dataPath The local URL that stores the data for the file.
 @param type The content-type of the file.
 @param progressBlock Optionally track the upload progress.
 @param completionBlock Optionally get an updated reference to the created file when complete.
 @param cancellationBlock Optionally be notified of a cancellation on upload.
 @param errorBlock Optionally be notified of an error.
 */
- (void)update: (NSURL*)dataPath
      withType: (NSString*)type
    onProgress: (void (^)(double fractionCompleted))progressBlock
  onCompletion: (void (^)(AdobeCloudFile* file))completionBlock
onCancellation: (void (^)(void))cancellationBlock
       onError: (void (^)(NSError* error))errorBlock;

/**
 Cancel the update request.
 */
- (void)cancelUpdateReqest;

/**
 Cancel the priority of the upload. By default: NSOperationQueuePriorityNormal.
 
 @param priority The priority of the request.
 */
- (void)changeUpdateRequestPriority:(NSOperationQueuePriority)priority;

/**
 Delete a file from the Adobe Creative Cloud asynchronously.
 
 @param completionBlock Optionally be notified when complete.
 @param errorBlock Optionally be notified of an error.
*/
- (void)delete: (void (^)(void))completionBlock
       onError: (void (^)(NSError* error))errorBlock;

/**
 Get a rendition of the file asynchronously.
 
 @param type The type of rendition to request.
 @param dimensions The dimensions of the rendition.
 @param priority The priority of the request.
 @param progressBlock Optionally track the upload progress.
 @param completionBlock Get the rendition data, and notified if returned from local cache.
 @param cancellationBlock Optionally be notified of a cancellation on upload.
 @param errorBlock Optionally be notified of an error.
 */
- (void)getRenditionWithType: (AdobeCloudFileRenditionType)type
                    withSize: (CGSize)dimensions
                withPriority: (NSOperationQueuePriority)priority
                  onProgress: (void (^)(double fractionCompleted))progressBlock
                onCompletion: (void (^)(NSData* data, BOOL fromCache))completionBlock
              onCancellation: (void (^)(void))cancellationBlock
                     onError: (void (^)(NSError* error))errorBlock;

/**
 Get a rendition of a page from a multi-paged file asynchronously.
 
 @param type The type of rendition to request.
 @param dimensions The dimensions of the rendition.
 @param page The page to get the rendition for.
 @param priority The priority of the request.
 @param progressBlock Optionally track the upload progress.
 @param completionBlock Get the rendition data, and notified if returned from local cache.
 @param cancellationBlock Optionally be notified of a cancellation on upload.
 @param errorBlock Optionally be notified of an error.
 */
- (void)getRenditionWithType: (AdobeCloudFileRenditionType)type
                    withSize: (CGSize)dimensions
                     forPage: (NSUInteger)page
                withPriority: (NSOperationQueuePriority)priority
                  onProgress: (void (^)(double fractionCompleted))progressBlock
                onCompletion: (void (^)(NSData* data, BOOL fromCache))completionBlock
              onCancellation: (void (^)(void))cancellationBlock
                     onError: (void (^)(NSError* error))errorBlock;

/**
 Cancel the rendition request.
 */
- (void)cancelRenditionRequest;

/**
 Cancel the priority of the rendition request.
 
 @param priority The priority of the request.
 */
- (void)changeRenditionRequestPriority:(NSOperationQueuePriority)priority;

/**
 Get the data of the file asynchronously.
 
 @param priority The priority of the request.
 @param progressBlock Optionally track the upload progress.
 @param completionBlock Get the rendition data, and notified if returned from local cache.
 @param cancellationBlock Optionally be notified of a cancellation on upload.
 @param errorBlock Optionally be notified of an error.
 */
- (void)getData: (NSOperationQueuePriority)priority
     onProgress: (void (^)(double fractionCompleted))progressBlock
   onCompletion: (void (^)(NSData* data, BOOL fromCache))completionBlock
 onCancellation: (void (^)(void))cancellationBlock
        onError: (void (^)(NSError* error))errorBlock;

/**
 Get the data of a page from a multi-paged file asynchronously.
 
 @param page The page to get the rendition for.
 @param priority The priority of the request.
 @param progressBlock Optionally track the upload progress.
 @param completionBlock Get the rendition data, and notified if returned from local cache.
 @param cancellationBlock Optionally be notified of a cancellation on upload.
 @param errorBlock Optionally be notified of an error.
 */
- (void)getDataForPage: (NSUInteger)page
          withPriority: (NSOperationQueuePriority)priority
            onProgress: (void (^)(double fractionCompleted))progressBlock
          onCompletion: (void (^)(NSData* data, BOOL fromCache))completionBlock
        onCancellation: (void (^)(void))cancellationBlock
               onError: (void (^)(NSError* error))errorBlock;

/**
 Cancel the data request.
 */
- (void)cancelDataRequest;

/**
 Cancel the priority of the data request.
 
 @param priority The priority of the request.
 */
- (void)changeDataRequestPriority:(NSOperationQueuePriority)priority;

/**
 Set the version of the Cloud File.
 
 @param version The version to set as the current version of the Cloud File.
 */
- (void)setVersion: (NSUInteger)version;

/**
 A utility to test the equality of two AdobeCloudFiles.

 @param file the AdobeCloudFile to test against.
 */
- (BOOL)isEqualToFile: (AdobeCloudFile *)file;

- (NSString *)description;

@end
