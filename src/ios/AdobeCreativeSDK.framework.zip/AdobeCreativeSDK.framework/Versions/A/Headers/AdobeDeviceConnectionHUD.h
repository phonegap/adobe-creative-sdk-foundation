/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <UIKit/UIKit.h>

/*! Connection HUD Type */
typedef NS_ENUM(NSUInteger, AdobeDeviceConnectionHUDType)
{
    /*! Connected */
    AdobeDeviceConnectionHUDTypeConnected,
    /*! Disconnected */
    AdobeDeviceConnectionHUDTypeDisconnected
};

@interface AdobeDeviceConnectionHUD : UIView <UIAppearance>

@property (nonatomic, assign) UIColor *backgroundColor UI_APPEARANCE_SELECTOR;
@property (nonatomic, assign) NSNumber *cornerRadius UI_APPEARANCE_SELECTOR;
@property (nonatomic, assign) NSNumber *borderSize UI_APPEARANCE_SELECTOR;
@property (nonatomic, assign) UIColor *borderColor UI_APPEARANCE_SELECTOR;

@property (nonatomic, assign) UIImage *connectedIcon UI_APPEARANCE_SELECTOR;
@property (nonatomic, assign) UIImage *disconnectedIcon UI_APPEARANCE_SELECTOR;

@property (nonatomic, assign) NSString *connectedLabel UI_APPEARANCE_SELECTOR;
@property (nonatomic, assign) NSString *disconnectedLabel UI_APPEARANCE_SELECTOR;

- (void)showWithDuration:(NSUInteger)duration inView:(UIView*)view withType:(AdobeDeviceConnectionHUDType)type;

@end
