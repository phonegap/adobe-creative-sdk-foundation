/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 * THIS FILE IS PART OF THE CREATIVE SDK PUBLIC API
 *
 ******************************************************************************/

#import <Foundation/Foundation.h>

/**
 
 AdobeAuthUserProfile contains the properties of the currently logged in user as obtained by calling
 [AdobeAuthManager getUserProfile].
 
 See AdobeAuthManager

 */
@interface AdobeAuthUserProfile : NSObject

/**
 The Adobe ID of the user.
 */
@property (nonatomic, readonly, strong) NSString * adobeID;

/**
 The display name of the user.
 */
@property (nonatomic, readonly, strong) NSString * displayName;

/**
 The first name of the user.
 */
@property (nonatomic, readonly, strong) NSString * firstName;

/**
 The last name of the user.
 */
@property (nonatomic, readonly, strong) NSString * lastName;

/**
 The email address of the user.
 */
@property (nonatomic, readonly, strong) NSString * email;

/**
 The object in a readable format.
 */
- (NSString *)description;

@end
