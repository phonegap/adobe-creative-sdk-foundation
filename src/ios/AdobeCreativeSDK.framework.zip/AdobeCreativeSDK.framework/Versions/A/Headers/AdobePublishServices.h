/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/

/**
 `AdobePublishPrivacyLevel` identifies the privacy settings for content on the Behance network
 */
typedef NS_ENUM(NSInteger, AdobePublishPrivacyLevel) {
    /**
     `AdobePublishPrivacyLevelPublic` means content is visible to everyone
     */
    AdobePublishPrivacyLevelPublic            = 0,
    
    /**
     `AdobePublishPrivacyLevelPrivate` means content is visible to only the owner
     */
    AdobePublishPrivacyLevelPrivate           = 1,
    
    /**
     `AdobePublishPrivacyLevelFeedbackCircle` means content is visible to members of the owners feedback circle.
     */
    AdobePublishPrivacyLevelFeedbackCircle    = 2 // Deprecated
};

/**
 `AdobePublishMatureAccess` identifies access restrictions for viewing mature content
 */
typedef NS_ENUM(NSInteger, AdobePublishMatureAccess) {
    /**
     Mature content viewing is allowed
     */
    AdobePublishMatureAccessAllowed = 0,
    
    /**
     Mature content is restricted because the user is logged out
     */
    AdobePublishMatureAccessRestrictedLoggedOut = 1,
    
    /**
     Mature content is restricted by the user's geographic location
     */
    AdobePublishMatureAccessRestrictedGeo = 2,
    
    /**
     Mature content is restricted by the user's age
     */
    AdobePublishMatureAccessRestrictedAge = 3,
    
    /**
     Mature content is restricted by the user's preference
     */
    AdobePublishMatureAccessRestrictedSafe = 4
};

/**
 `BehanceSDK` is a wrapper for the publicly available Behance API, documented at http://behance.net/dev. It provides convenience methods for making REST requests and returning fully-formed model objects.
 
 Users are required to register their applications at the above URL to receive an API key and API secret. These must be provided to `BehanceSDK` before making any API calls.
 */
@interface AdobePublishServices : NSObject

/**
 The API key used to make all requests to the Behance API. Register your application at: http://www.behance.net/dev
 */
@property (nonatomic, readonly) NSString * apiKey;

/**
 The API secret used to make all requests to the Behance API. Register your application at: http://www.behance.net/dev
 */
@property (nonatomic, readonly) NSString * apiSecret;

/**
 The Base URL used to make all requests to the Behance API.
 */
@property (nonatomic, readonly) NSString * apiBaseURL;

/**
 The Redirect URI used to make all requests to the Behance API. Register your application at: http://www.behance.net/dev
 */
@property (nonatomic, readonly) NSString * redirectURI;

/**
 Creates and returns an `BehanceSDK` object.
 
 @return The newly-initialized `BehanceSDK` object.
 */
+ (AdobePublishServices *)sharedInstance;

/**
 The API key used to make all requests to the Behance API. Register your application at: http://www.behance.net/dev
 
 @param apiKey The API key for your application.
 */
- (void)setAPIKey:(NSString *)apiKey;

/**
 The API secret used to make all requests to the Behance API. Register your application at: http://www.behance.net/dev
 
 @param apiSecret The API secret for your application.
 */
- (void)setAPISecret:(NSString *)apiSecret;

/**
 The Redirect URI used to make all requests to the Behance API. Register your application at: http://www.behance.net/dev
 
 @param redirectURI The Redirect URI for your application.
 */
- (void)setRedirectURI:(NSString *)redirectURI;

@end
