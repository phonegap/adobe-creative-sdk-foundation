//
//  AdobeKulerLearnedThemes.h
//  AdobeKuler
//
//  Created by Wally Ho on 12/9/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AdobeKulerThemes.h"

/**
 * To be documented
 */
@interface AdobeKulerLearnedThemes : NSObject

+ (void) setPersistentThemes:(AdobeKulerThemes*) themes withAdobeId:(NSString *) subDirectoryAdobeId;
+ (AdobeKulerThemes*) getPersistentThemesWithAdobeId:(NSString *) subDirectoryAdobeId;

+ (void) setPersistentThemes:(AdobeKulerThemes*) themes withAdobeId:(NSString *) subDirectoryAdobeId andFilename:(NSString*) filename;
+ (AdobeKulerThemes*) getPersistentThemesWithAdobeId:(NSString *) subDirectoryAdobeId andFilename:(NSString*) filename;
@end
