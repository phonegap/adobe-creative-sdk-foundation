//
//  UIColor+AdobeKulerColorUtils.h
//  AdobeKuler
//
//  Created by Wally Ho on 11/6/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 * To be documented
 */
@interface UIColor (AdobeKulerColorUtils)

+ (UIColor*) getColorFromHexString:(NSString*)hexString;

@end
