/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

@class AdobeDeviceInkPasteboardItem;

@protocol AdobeDeviceClipboardDelegate <NSObject>

/**
 * Called when an item in the clipboard viewer is selected by the user
 * in the clipboard viewer
 * @param pasteboardItem The AdobeDeviceInkPasteboardItem representing the user's selection
 */
- (void)clipboardItemSelected:(AdobeDeviceInkPasteboardItem *)pasteboardItem;

@end
