/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 * THIS FILE IS PART OF THE CREATIVE SDK PUBLIC API
 *
 ******************************************************************************/

#import <Foundation/Foundation.h>

#import "AdobeAuthError.h"
#import "AdobeAuthEndpoint.h"
#import "AdobeAuthUserProfile.h"

/**
 Sent when authentication failed after too many attempts
 */
extern NSString* const AdobeAuthManagerTooManyAuthErrorsNotification;

/**
 The notification sent via the NSNotificationManager when a login has been made
 by the AdobeAuthManager.
 */
extern NSString* const AdobeAuthManagerLoggedInNotification;

/**
 The notification sent via the NSNotificationManager when a logout has been made
 by the AdobeAuthManager.
 */
extern NSString* const AdobeAuthManagerLoggedOutNotification;

/**
 AdobeAuthManager is the class by which authentication with the Adobe Creative Cloud is managed.
 
 It allows clients to:
 
 - Specify the type of Creative Cloud endpoint they wish to use, their deviceName, clientID, and clientSecret as issued by Adobe.
 - Query for authentication status.
 - Get the user profile of the currently authenticated user.
 - Logout the currently logged in user.
 - <font color="red">**TEMPORARY:** Retrieve the IMS token of the currently logged in user.</font>
 
 Login and Logout notification are sent via the NSNotificationManager.  The NSNotificationManager will send<br>
 <code>extern NSString\* const AdobeAuthManagerLoggedInNotification</code><br>when a login occurs and<br>
 <code>extern NSString\* const AdobeAuthManagerLoggedOutNotification</code><br>
 when a logout occurs.
 */
@interface AdobeAuthManager : NSObject

/**
 Returns whether or not there is a currently logged in user.
 
 @returns YES if there is a user authenticated, NO if there is no currently logged in user.
 */
@property (nonatomic, readonly, unsafe_unretained, getter = isAuthenticated) BOOL authenticated;

/**
 Gets the user profile of the currently logged in user.
 
 @returns the user profile of the currently logged in user or nil if no user is currently logged in.
 @see AdobeAuthUserProfile
 */
@property (nonatomic, readonly, strong) AdobeAuthUserProfile* userProfile;

/**
 Get the Auth Manager singleton.
 
 @returns the singleton object.
 */
+ (AdobeAuthManager *)sharedManager;

/**
 Sets the authentication parameters for Creative Cloud Authentication.
 
 This function should be called once upon application startup.
 
 This function does not initiate login, rather login is triggered automatically when necessary whenever
 Creative Cloud services are accessed or when login is called explicitly.
 
 @param endpoint The AdobeAuthEndpoint type of the Creative Cloud Servers to connect to
 @param deviceName The deviceName for authentication as supplied to the application developer by Adobe
 @param clientID The clientID as supplied to the application developer by Adobe
 @param clientSecret The client secret for the application as supplied to the application developer by Adobe
 */
- (void)setAuthenticationEndpoint: (AdobeAuthEndpoint)endpoint
                   withDeviceName: (NSString *)deviceName
                     withClientID: (NSString *)clientID
                 withClientSecret: (NSString *)clientSecret;

/**
 Logs in the user.
 
 @param parentViewController the view controller that will host any UI elements needed for login
 @param successBlock the block of code that gets called upon login success
 @param errorBlock the block of code that gets called upon login failure
 @note This call is not explicity needed to be called. If a token is required, it will be called lazily.
 */
- (void)login: (UIViewController *)parentViewController
    onSuccess: (void (^)(AdobeAuthUserProfile* profile))successBlock
      onError: (void (^)(NSError* error))errorBlock;

/**
 Logs out the currently logged in user.
 
 @param successBlock the block of code that gets called upon logout success
 @param errorBlock the block of code that gets called upon logout failure
 */
- (void)logout: (void (^)(void))successBlock
       onError: (void (^)(NSError* error))errorBlock;

@end

#import "AdobeAuthManager_Restricted.h"
