//
//  AdobeKulerClient.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/23/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import "AdobeKulerEndpointModel.h"
#import "AdobeKulerClientInfo.h"

/**
 * To be documented
 */
@interface AdobeKulerClient : NSObject

- (id) initWithClientInfo: (AdobeKulerClientInfo*) kulerClient;

- (BOOL) isSignedIn;

- (void) setClientParameters: (AdobeKulerClientInfo*) kulerClient;

- (void) getKulerPopularThemesWithSuccessCompletion:(AdobeKulerSuccessBlockThemes ) successComplete
                                    withParamemters: (NSDictionary*) parameters
                                  onErrorCompletion:(AdobeKulerErrorBlock) errorComplete;

- (void) getKulerRandomThemesWithSuccessCompletion:(AdobeKulerSuccessBlockThemes) successComplete
                                   withParamemters: (NSDictionary*) parameters
                                 onErrorCompletion:(AdobeKulerErrorBlock) errorComplete;

- (void) getKulerMyThemesWithSuccessCompletion:(AdobeKulerSuccessBlockThemes) successComplete
                               withParamemters: (NSDictionary*) parameters
                             onErrorCompletion:(AdobeKulerErrorBlock) errorComplete;

- (void) getKulerFavouriteThemesWithSuccessCompletion:(AdobeKulerSuccessBlockThemes) successComplete
                                    onErrorCompletion:(AdobeKulerErrorBlock) errorComplete;


- (void) postKulerMyThemes:(AdobeKulerThemes*) themes
     withSuccessCompletion:(AdobeKulerSuccessBlockWithDictionary) successComplete
         onErrorCompletion:(AdobeKulerErrorBlock) errorComplete;
@end


