/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/**
 `AdobePublishWIPSpecs` wraps all fields available for publishing projects and works in progress to the Behance network.
 
 All fields except `image` are optional. Any fields provided will be pre-filled in the work in progress publishing UI. 
 All fields except `image` can be overridden by the user.
 */

@interface AdobePublishWIPSpecs : NSObject

/**
 UIImage to be published as a work in progress.
 
 @warning This field is required.
 */
@property (nonatomic, strong) UIImage * image;

/*
 Title of the work in progress to be published.
 @warning If an `originalWIPId` is provided, title will be ignored.
 */
@property (nonatomic, strong) NSString * title;

/*
 Description of the work in progress to be published.
 */
@property (nonatomic, strong) NSString * wipDescription;

/*
 Array of `NSString` tags to associate with the work in progress to be published.
 @warning If an `originalWIPId` is provided, tags will be ignored.
 */
@property (nonatomic, strong) NSArray * tags;

/*
 If this is a revision of an existing work in progress
 @warning If an `originalWIPId` is provided, title and tags will be ignored as the original WIP's title and tags carry over.
 */
@property (nonatomic, strong) NSNumber * originalWIPId;

@end
