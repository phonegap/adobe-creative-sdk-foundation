/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2014 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 * THIS FILE IS PART OF THE CREATIVE SDK PUBLIC API
 *
 ******************************************************************************/

/**
 
 AdobeAuthErrorCode is an enumerated type that specifies the type of error that
 may occur during authentication.
 
 See AdobeAuthManager
 
 */

#import <Foundation/Foundation.h>

extern NSString* const AdobeAuthErrorDomain;

typedef NS_ENUM( NSInteger, AdobeAuthErrorCode ) {
    /** offline */
    AdobeAuthErrorCodeOffline = kCFURLErrorNotConnectedToInternet,
    /** no error */
    AdobeAuthErrorCodeNoError = 0,
    /** user cancelled authentication */
    AdobeAuthErrorCodeUserCancelled = 1,
    /** no user name and password were specified */
    AdobeAuthErrorCodeUsernameAndPasswordRequired = 2,
    /** device id required */
    AdobeAuthErrorCodeDeviceIDRequired = 3,
    /** client id requiered */
    AdobeAuthErrorCodeClientIDRequired = 4,
    /** invalid argument */
    AdobeAuthErrorCodeInvalidArgument = 5,
    /** an unknown error occurred */
    AdobeAuthErrorCodeUnknownError = 99
};

@interface AdobeAuthError : NSObject

@end
