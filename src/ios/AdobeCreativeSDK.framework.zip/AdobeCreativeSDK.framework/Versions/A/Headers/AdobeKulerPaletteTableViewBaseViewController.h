//
//  AdobeKulerPaletteTableViewBaseViewController.h
//  AdobeKuler
//
//  Created by Wally Ho on 12/5/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AdobeKulerTheme.h"
#import "AdobeKulerThemes.h"
#import "AdobeKulerClient.h"
#import "AdobeKulerClientInfo.h"

/**
 * To be documented
 */
@interface AdobeKulerPaletteTableViewBaseViewController : UIViewController

@property (strong, nonatomic) NSIndexPath* selectedIndexPathForMove;
@property (strong, nonatomic) AdobeKulerClient * kulerClient;
@property (strong, nonatomic) AdobeKulerThemes * kulerThemes;
@property (unsafe_unretained, nonatomic) NSInteger kulerThemesCount;
@property(unsafe_unretained, nonatomic) BOOL isDeleteButtonHidden;
@end

