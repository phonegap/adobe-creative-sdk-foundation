/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

#define PEN_MIN_PRESSURE 0
#define PEN_MAX_PRESSURE 2047

@protocol AdobeDeviceInkTouchDelegate;
@protocol AdobeDeviceInkManagerDelegate;

/**
 * to be documented
 */
typedef NS_ENUM(NSInteger, AdobeDeviceInkConnectionStatus)
{
    /** to be documented */
    AdobeDeviceInkConnectionStatusDisconnected,
    /** to be documented */
    AdobeDeviceInkConnectionStatusScanning,
    /** to be documented */
    AdobeDeviceInkConnectionStatusConnected
};

@class AdobeDeviceInk;

/**
 * AdobeDeviceInkManager allows clients to manage the connection with the pen device
 */
@interface AdobeDeviceInkManager : NSObject

/**
 * The Pen Touch Delegate capture touches events for the registered view.
 * If there isn't any registered view, no touches are going to be captured.
 * In case Palm Rejection is turned ON, it also suggest to enable or disable gestures in case it detects a palm.
 */
@property (nonatomic,assign) id<AdobeDeviceInkTouchDelegate> penTouchDelegate;

/**
 * TODO
 */
@property (nonatomic,assign) id<AdobeDeviceInkManagerDelegate> penManagerDelegate;

/**
 * Currently connected Pen.
 */
@property (nonatomic,readonly) AdobeDeviceInk *connectedPen;

/**
 * Default Pressure for finger touches or unconnected pens.
 **/
@property (readwrite) NSUInteger unconnectedPressure;

/**
 * Pen Current Connection Status
 */
@property (nonatomic,readonly) AdobeDeviceInkConnectionStatus connectionStatus;

/**
 * A boolean specifying whether palm rejection is on or not.
 */
@property (readwrite) BOOL enablePalmRejection;

/**
 * Force Pen disconnection.
 */
- (void)forcePenDisconnect;

/**
 * Sets a view to receive touch events from Pen.
 * The copy/paste gesture recognizers will also be linked to that view automatically.
 * @param view A view that will be supplied touch events from Pen styluses
 */
- (void)registerView:(UIView*)view;

/**
 * Removes view from receiving touch events from Pen styluses.
 * @param view A view that will no longer receiver touch events from Jot styluses
 */
- (void)unregisterView:(UIView*)view;


@end
