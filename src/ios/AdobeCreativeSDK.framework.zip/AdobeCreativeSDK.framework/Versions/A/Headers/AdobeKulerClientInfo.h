//
//  AdobeKulerClientInfo.h
//  AdobeKuler
//
//  Created by Wally Ho on 9/30/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ADBESignInClient;

/**
 * To be documented
 */
typedef NS_ENUM(NSInteger, AdobeKulerClientInfoEnvironment)
{
    /** to be documented */
    AdobeKulerClientInfoEnvironmentNone = 0,
    AdobeKulerClientInfoEnvironmentProd = 1,
    AdobeKulerClientInfoEnvironmentStage = 2
};

/**
 * To be documented
 */
@interface AdobeKulerClientInfo : NSObject

@property(strong, nonatomic) NSString* accessToken;
@property (copy,nonatomic) NSString* kulerHost;
@property (copy,nonatomic) NSString* kulerRESTApiKey;
@property (unsafe_unretained, nonatomic) AdobeKulerClientInfoEnvironment kulerEnvironment;


@end
