/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class AdobeDeviceInkPasteboardItem;
@class AdobeDeviceInkManager;

/*! Pasteboard Action */
typedef NS_ENUM(NSUInteger, AdobeDeviceInkPasteboardAction)
{
    /*! Pasteboard Copy Action */
    AdobeDeviceInkPasteboardActionCopy,
    /*! Pasteboard Paste Action */
    AdobeDeviceInkPasteboardActionPaste
};

/*! Pasteboard Action Type */
typedef NS_ENUM(NSUInteger, AdobeDeviceInkPasteboardActionType)
{
    /*! Pasteboard Local Action. The action is executed locally only */
    AdobeDeviceInkPasteboardActionTypeLocal,
    /*! Pasteboard Cloud Action. The action is executed Locally first and then in the Cloud thru Creative Cloud Storage API */
    AdobeDeviceInkPasteboardActionTypeCloud,
    /*! Nothing found either in the Local pasteboard or cloud pasteboard */
    AdobeDeviceInkPasteboardActionTypeNone
};

@protocol AdobeDeviceInkPasteboardDelegate;


/**
 * Class responsible for the Mighty Local+Cloud Pasteboard
 */
@interface AdobeDeviceInkPasteboard : NSObject

/**
 * Enable or Disable the Mighty Copy/Paste workflow. 
 * By default the value is YES.
 */
@property (nonatomic,readwrite, getter = isEnable) BOOL enable;

/**
 * Pasteboard delegate capturing copy/paste events and workflow.
 * If no delegate is passed. the copy/paste flow is ignored. Similar to enable=NO.
 * @see AdobeDeviceInkPasteboardDelegate
 */
@property (nonatomic,assign) id<AdobeDeviceInkPasteboardDelegate> pasteboardDelegate;

@end


/**
 * Pasteboard delegate capturing copy/paste events and workflow.
 */
@protocol AdobeDeviceInkPasteboardDelegate <NSObject>
@required

/**
 * This method is called as soon as a copy or paste pen gesture is recognized in order to know if the action can be performed.
 *
 * @param pasteboard the current Pasteboard instance.
 * @param action the current action. can be 'AdobeDeviceInkPasteboardActionCopy' or 'AdobeDeviceInkPasteboardActionPaste'.
 * @param position the current x/y position at which the copy action was initiated.
 * @param view the view in which the copy action was initiated.
 *
 * @return a Boolean. YES if you want to pursue the copy or paste action. NO if you want to cancel the action immediately.
 */
- (BOOL)pasteboard:(AdobeDeviceInkPasteboard *)pasteboard canPerformAction:(AdobeDeviceInkPasteboardAction)action
        atPosition:(CGPoint)position
            inView:(UIView*)view;

/**
 * This method is called just before executing the copy action.
 *
 * @param pasteboard the current Pasteboard instance.
 * @param position the current x/y position at which the copy action was initiated.
 * @param view the view in which the copy action was initiated.
 * @param actionType the Pasteboard action type. it can be Local or Cloud.
 *
 * @return the content to copy wrapped into an AdobeDeviceInkPasteboardItem. if nil is returned an Exception is thrown
 */
- (AdobeDeviceInkPasteboardItem *)pasteboard:(AdobeDeviceInkPasteboard *)pasteboard willPerformCopyActionAtPosition:(CGPoint)position
                          inView:(UIView*)view
                            type:(AdobeDeviceInkPasteboardActionType)actionType;

/**
 * This method is called just before executing the paste action.
 *
 * @param pasteboard the current Pasteboard instance.
 * @param position the current x/y position at which the paste action was initiated.
 * @param view the view in which the paste action was initiated.
 * @param actionType the Pasteboard action type. it can be Local or Cloud.
 * @param mediaType the original content-type of the item to be pasted.
 *
 * @return the rendition content-type. if nil is returned an Exception is thrown
 */
- (NSString*)pasteboard:(AdobeDeviceInkPasteboard *)pasteboard willPerformPasteActionAtPosition:(CGPoint)position
                 inView:(UIView*)view
                   type:(AdobeDeviceInkPasteboardActionType)actionType
              mediaType:(NSString*)mediaType;

/**
 * This method is called when the copy or paste action succeeded.
 *
 * @param pasteboard the current Pasteboard instance.
 * @param action the current action. can be 'AdobeDeviceInkPasteboardActionCopy' or 'AdobeDeviceInkPasteboardActionPaste'.
 * @param position the current x/y position at which the paste action was initiated.
 * @param view the view in which the action was initiated.
 * @param actionType the Pasteboard action type. it can be Local or Cloud.
 * @param item the content that was copied or pasted wrapped into an AdobeDeviceInkPasteboardItem object.
 */
- (void)pasteboard:(AdobeDeviceInkPasteboard *)pasteboard didFinishPerformAction:(AdobeDeviceInkPasteboardAction)action
        atPosition:(CGPoint)position
            inView:(UIView*)view
              type:(AdobeDeviceInkPasteboardActionType)actionType
     clipboardItem:(AdobeDeviceInkPasteboardItem *)item;

/**
 * This method is called if the copy or paste action failed.
 *
 * @param pasteboard the current Pasteboard instance.
 * @param action the current action. can be Copy or Paste.
 * @param error the error.
 * @param actionType the Pasteboard action type. it can be Local or Cloud.
 */
- (void)pasteboard:(AdobeDeviceInkPasteboard *)pasteboard didFailedPerformAction:(AdobeDeviceInkPasteboardAction)action
         withError:(NSError*)error
              type:(AdobeDeviceInkPasteboardActionType)actionType;

@end
