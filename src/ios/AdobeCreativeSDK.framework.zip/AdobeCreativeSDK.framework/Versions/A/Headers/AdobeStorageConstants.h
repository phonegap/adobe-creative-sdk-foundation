/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 * THIS FILE IS PART OF THE CREATIVE SDK PUBLIC API
 *
 ******************************************************************************/

/** The mime type for octet streams */
extern NSString* const kMimeTypeOctetStream;

/** The mime type for photoshop documents */
extern NSString* const kMimeTypePhotoshop;

/** The mime type for jpeg files */
extern NSString* const kMimeTypeJPEG;

/** The mime type for illustrator documents */
extern NSString* const kMimeTypeIllustrator;

/** The mime type for gif files */
extern NSString* const kMimeTypeGIF;

/** The mime type for png files */
extern NSString* const kMimeTypePNG;

/** The mime type for tiff files */
extern NSString* const kMimeTypeTIFF;

/** The mime type for bmp files */
extern NSString* const kMimeTypeBMP;

/** The mime type for pdf files */
extern NSString* const kMimeTypePDF;

/** The mime type for dmg files */
extern NSString* const kMimeTypeDMG;

/** The mime type for dng files */
extern NSString* const kMimeTypeDNG;

/** The mime type for raw files */
extern NSString* const kMimeTypeRaw;

