/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <Foundation/Foundation.h>

@class AdobeDeviceInkManager;
@class AdobeDeviceInk;

@protocol AdobeDeviceInkManagerDelegate <NSObject>
@optional
- (void)startScanningForPenWithPenManager:(AdobeDeviceInkManager *)penManager;
- (void)stopScanningForPenWithPenManager:(AdobeDeviceInkManager *)penManager;

- (void)penManager:(AdobeDeviceInkManager *)penManager didConnectPen:(AdobeDeviceInk *)pen;
- (void)penManager:(AdobeDeviceInkManager *)penManager didDisconnectPen:(AdobeDeviceInk *)pen;

@end
