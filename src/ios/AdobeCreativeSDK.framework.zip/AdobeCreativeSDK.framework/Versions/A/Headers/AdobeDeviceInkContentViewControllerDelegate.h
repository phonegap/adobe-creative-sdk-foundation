/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/
#import <Foundation/Foundation.h>

@class AdobeDeviceNodeAppearance;
@protocol AdobeDeviceInkMenuPopoverDelegate;

/**
 * This protocol defines the contract between the content view controller and the Pen Tip Menu that host the feature.
 * You must conforms your content UIViewController to this protocol in order to make it work within the Pen Tip Menu.
 */
@protocol AdobeDeviceInkContentViewControllerDelegate <NSObject>
@required

/**
 * This object represent the look&feel of the given custom Node. It includes the icon, border, background colours, etc .. It is the developer responsibility to instantiate a new `AdobeDeviceNodeAppearance` and fill it with whatever is needed. You can create a new instance by doing `[AdobeDeviceNodeAppearance create];` All properties are KVO's and therefore the node button will be automatically updated when a property of `AdobeDeviceNodeAppearance` is changed. Any properties set in the nodeAppearance property of your UIViewController will take precedence over the default global appearance.
 */
@property (nonatomic,readonly) AdobeDeviceNodeAppearance *nodeAppearance;

/**
 * This is an `NS_OPTION` that define the popover arrow direction. It is the developer responsibility to define this property within their UIViewController.
 * `delegate` property: This delegate conforms to `AdobeDeviceInkMenuPopoverDelegate` and let you dismiss the popover container of the given UIViewController which is handy to force dismissing the popover when needed *(eg. when the user picked an option you want to automatically dismiss the popover and come back to the pen tip menu)*
 */
@property (nonatomic,readonly) UIPopoverArrowDirection popoverArrowDirection;

/**
 * This is the delegate that points to the host controller. It let you control the parent popover container. 
 * This property is automatically set after you pass the Content View Controller to the Pen Tip Menu View Controller.
 */
@property (nonatomic) id<AdobeDeviceInkMenuPopoverDelegate> popoverDelegate;

/**
 * This boolean let the Ink Menu know if there is any popover to display when the user tap the node. It is the developer responsability to synthetise and implement the getter to return YES or NO depending of the needs.
 * This is handy in order to create for example a Node that serve as a Toggle without any sub-content.
 */
@property (nonatomic,readonly) BOOL hasPopoverContent;


@optional
/**
 * This is called when the Node that is controlling this ViewController triggered the 'TouchUpInside' event. Handy in case you want to create a Toggle node type of behavior.
 */
- (void) nodeDidTouchUpInside;

@end



/**
 * Protocol to let you control the parent popover container.
 * The delegate instance is injected automatically to each Pen Tip Menu Content View Controller that conforms to `AdobeDeviceInkContentViewControllerDelegate`
 */
@protocol AdobeDeviceInkMenuPopoverDelegate <NSObject>

/**
 * force dismiss the parent popover
 */
- (void) dismissPopover;

@end
