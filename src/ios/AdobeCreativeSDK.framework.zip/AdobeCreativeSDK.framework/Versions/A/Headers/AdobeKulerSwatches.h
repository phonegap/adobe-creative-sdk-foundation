//
//  AdobeKulerSwatches.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/29/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "AdobeKulerTag.h"

@class AdobeKulerSwatch;

/**
 * To be documented
 */
typedef NS_ENUM (NSInteger, AdobeKulerSelectedSwatch)
{
    /** to be documented */
    AdobeKulerSelectedSwatchNone=-1,
    /** to be documented */
    AdobeKulerSelectedSwatch1=0,
    /** to be documented */
    AdobeKulerSelectedSwatch2=1,
    /** to be documented */
    AdobeKulerSelectedSwatch3=2,
    /** to be documented */
    AdobeKulerSelectedSwatch4=3,
    /** to be documented */
    AdobeKulerSelectedSwatch5=4
};


/**
 * To be documented
 */
@interface AdobeKulerSwatches : NSObject <NSCoding>

@property (unsafe_unretained, nonatomic) NSInteger totalCountSwatches;
@property (unsafe_unretained, nonatomic) AdobeKulerSelectedSwatch swatchSelected;
@property (strong, nonatomic) NSArray* swatchArray;  // array of AdobeKulerSwatch should be 5

- (NSDictionary*) dictionaryRepresentation;
+ (AdobeKulerSwatches *) objectFromDictionary:(NSDictionary *)dictResponse;
@end


/**
 * To be documented
 */
@interface AdobeKulerSwatch : NSObject

@property (copy, nonatomic) NSString* swatchName;
@property (copy, nonatomic) NSString* swatchMode;  //rgb|cmyk|lab|hsv
@property (copy, nonatomic) NSString* swatchHex;  //No 0x..
@property (strong, nonatomic) UIColor* swatchColor;
@property (strong, nonatomic) NSArray* swatchColorComponentValues;


- (NSDictionary*) dictionaryRepresentation;
+ (AdobeKulerSwatch *) objectFromDictionary:(NSDictionary *)dictResponse;
@end
