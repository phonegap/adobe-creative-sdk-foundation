/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

//  AdobePatentID="3106US02"

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "AdobeDeviceSlideShape.h"

@protocol AdobeDeviceSlidePerspectiveDelegate;

@interface AdobeDeviceSlideView : UIView 

@property (strong, nonatomic) AdobeDeviceSlideShape *activeHandle;
@property (nonatomic) BOOL snapLeft;

- (void)carouselForward;
- (void)carouselBackwards;
- (void)switchToShapeAtIndexPath:(NSIndexPath *)indexPath;
- (void)snapToVanishingPoint:(CGPoint)vp
                   withColor:(UIColor *)snapLineColor
                   transform:(CGAffineTransform)transform;

@end


@protocol AdobeDeviceSlidePerspectiveDelegate <NSObject>

- (void)slideViewPerspVPToggled:(AdobeDeviceSlideView *)slideView;

@end
