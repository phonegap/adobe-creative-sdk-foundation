/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

typedef void (^PenFormattedNameSuccessBlock)(NSString *formattedName);
typedef void (^PenIdentityConfiguredCompletionBlock)(BOOL penConfigured);

/*! Pen Type */
typedef NS_ENUM(NSUInteger, AdobeDeviceInkType)
{
    /*! Adobe Mighty */
    AdobeDeviceInkTypeAdobeMighty,
    /*! Adonit JotTouch Pixel */
    AdobeDeviceInkTypeAdonitJTPP,
    /*! Adonit JotTouch 4 */
    AdobeDeviceInkTypeAdonitJT4,
    /*! Adonit Jot Script */
    AdobeDeviceInkTypeAdonitJS,
    /*! Other Adonit Non-Mighty Compatible Pen  */
    AdobeDeviceInkTypeOther
};

/**
 * AdobeDeviceInk represents a Pen Device.
 *
 */
@interface AdobeDeviceInk : NSObject

/**
 * The Pen Friendly Name. Returns nil if the connected Pen is not a Mighty Compatible pen.
 */
@property (nonatomic,readonly) NSString *identityName;

/**
 * The Pen Identity Color choosen by the user. Will return nil if the connected Pen is not a Mighty Compatible pen.
 * Will return black if user skipped the color selection during the setup.
 */
@property (nonatomic,readonly) UIColor *identityColor;

/**
 * The Pen identity name if it exist or a formatted name based on the serial number.
 */
@property (nonatomic,readonly) NSString *formattedFriendlyName;

/**
 * The pen type of the connected pen.
 */
@property (nonatomic,readonly) AdobeDeviceInkType penType;

/** 
 * A positive integer specifying the amount of battery remaining.
 */
@property (readonly) NSUInteger batteryLevel;


/** 
 * Obtains pressure data of the stylus currently connected.
 * @returns If connected, returns positive integer value of connected pressure data. If not connected, returns the unconnected pressure data.
 */
-(NSUInteger)getPressure;

/**
 * Tells you if the connected Pen is linked to a Creative Cloud Account.
 * Will return NO if the connected Pen is not a Mighty Compatible pen.
 */
@property (nonatomic,readonly,getter = isPenCreativeCloudAccountConfigured) BOOL penCreativeCloudAccountConfigured;

/**
 * Tells you if the connected Pen was configured successfuly thru the Mighty Setup Screens.
 * Will return NO if the connected Pen is not a Mighty Compatible pen.
 */
@property (nonatomic,readonly,getter = isPenIdentityConfigured) BOOL penIdentityConfigured;


/**
 * Tells you if the connected Pen is an Adobe Creative Cloud compatible pen.
 */
@property (nonatomic,readonly, getter = isPenCreativeClouldCompatible) BOOL penCreativeClouldCompatible;

/**
 * Pen's Firmware version
 */
@property (readonly) NSString *firmwareVersion;

/**
 * Pen's Hardware version
 */
@property (readonly) NSString *hardwareVersion;

/**
 * Pen's Serial Number
 */
@property (readonly) NSString *penSerialNumber;

/**
 * Pen's Owner Link if any otherwise nil
 */
@property (readonly) NSString *ownerLink;

/**
 * turn ON the Pen's LED with the Identity Color for 4 seconds.
 * Will do nothing if the connected Pen is not a Mighty Compatible pen.
 */
- (void)displayIdentityColor;

- (void)getFormattedFriendlyNameWithSuccessBlock:(PenFormattedNameSuccessBlock)block;


@end
