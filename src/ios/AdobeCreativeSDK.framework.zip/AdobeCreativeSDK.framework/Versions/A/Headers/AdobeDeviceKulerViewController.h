/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <UIKit/UIKit.h>
#import "AdobeDeviceInkContentViewControllerDelegate.h"
#import "AdobeDeviceInkManager.h"
#import "AdobeKulerTheme.h"
#import "AdobeKulerThemes.h"
#import "AdobeDeviceInkMenuViewController.h"

typedef void (^BlockComplete) (AdobeKulerTheme* selectedTheme);

/**
 * Built-in Kuler View Controller.
 *
 * This View Controller is an out of the box Kuler panel. 
 */
@interface AdobeDeviceKulerViewController : UIViewController <AdobeDeviceInkContentViewControllerDelegate>

@property (weak, nonatomic) id< AdobeDeviceInkMenuViewControllerKulerClipboardDelegate> delegateDeviceInkMenuViewControllerKulerClipboard;
@property (strong, nonatomic) AdobeKulerSwatch *activeSwatch;
@property (strong, nonatomic) AdobeKulerTheme *activeTheme;
@property (unsafe_unretained, nonatomic) BOOL isPenTheSource;
@property (unsafe_unretained, nonatomic ) BOOL isPenTheDeviceOwner;

- (void) onSwatchChange:(BlockComplete)block;
- (void) setThemesForKuler:(AdobeKulerThemes *) themesForKuler;

- (void) setIsPenTheSource:(BOOL)isPenTheSource;
- (void) setIsPenTheDeviceOwner:(BOOL)isPenTheDeviceOwner;
@end
