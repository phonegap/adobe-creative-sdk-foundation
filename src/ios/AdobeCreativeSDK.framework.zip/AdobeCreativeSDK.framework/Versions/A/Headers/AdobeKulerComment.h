//
//  AdobeKulerComment.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/29/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * To be documented
 */
@interface AdobeKulerComment : NSObject <NSCoding>

@property (unsafe_unretained, nonatomic) NSInteger commentCount;
@property (copy, nonatomic) NSString* commentId;
@property (copy, nonatomic) NSString* commentCommenterName;
@property (unsafe_unretained, nonatomic) NSInteger commentCommenterId;
//@property (strong, nonatomic) NSDate* commentCreated;
@property (strong, nonatomic) NSString* commentCreatedString;
@property (copy, nonatomic) NSString* commentContent;

-(NSDictionary*) dictionaryRepresentation;
+ (AdobeKulerComment *) objectFromDictionary:(NSDictionary *)dictResponse;
@end
