/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 * THIS FILE IS PART OF THE CREATIVE SDK PUBLIC API
 *
 ******************************************************************************/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// networking
#import "AdobePublishServices.h"
#import "AdobePublishSession.h"
#import "AdobePublishNetworkResponse.h"

// model objects
#import "AdobePublishBaseModel.h"
#import "AdobePublishActivity.h"
#import "AdobePublishCollection.h"
#import "AdobePublishComment.h"
#import "AdobePublishContentObject.h"
#import "AdobePublishCuratedGallery.h"
#import "AdobePublishProject.h"
#import "AdobePublishSearchFields.h"
#import "AdobePublishSearchField.h"
#import "AdobePublishUser.h"
#import "AdobePublishWorkInProgress.h"
#import "AdobePublishWIPRevision.h"

// activity action and types
#import "AdobePublishActivityActionItem.h"
#import "AdobePublishActivityItem.h"
#import "AdobePublishActivityAction.h"
#import "AdobePublishActivityAppreciation.h"
#import "AdobePublishActivityNewProject.h"
#import "AdobePublishActivityNewProjectComment.h"
#import "AdobePublishActivityNewWIP.h"
#import "AdobePublishActivitySavedToCollection.h"

// misc
#import "AdobePublishImageRef.h"

// project and wip creation
#import "AdobePublishProjectSpecs.h"
#import "AdobePublishWIPSpecs.h"

@protocol AdobePublishProjectDelegate;
@protocol AdobePublishWIPDelegate;

/**
 Account types that can be used for sharing published projects to other networks
 */
typedef NS_OPTIONS(NSInteger, AdobePublishAccountType)  {
    /** All known account types */
    AdobePublishAccountTypeAll              = 1 << 0,
    
    /** Facebook account type */
    AdobePublishAccountTypeFacebook         = 1 << 1,
    
    /** Twitter account type */
    AdobePublishAccountTypeTwitter          = 1 << 2,
};

/**
 `AdobePublish` is the base class for publishing projects and works in progress to the Behance network.
 */
@interface AdobePublish : NSObject

/**
 Facebook app id, for sharing published projects and works in progress to Facebook
 
 If a Facebook app id is not supplied, sharing to Facebook will be hidden.
 */
@property (nonatomic, strong) NSString * facebookAppId;

/**
 Creates and returns a `AdobePublish` singleton object.
 
 @return The newly-initialized `AdobePublish` singleton object.
 */
+ (AdobePublish *)sharedInstance;

/**
 Publish a project to Behance.  Presents in a modal view controller.
 
 @warning if specs.resourceOptions includes AdobePublishProjectSpecsResourceOptionCreativeCloud, you must first authenticate with the `AdobeAuthManager` using `setAuthenticationEndpoint:withDeviceName:withClientID:withClientSecret:withOptions:withAdditionalScopeList:`

 @param specs `AdobePublishProjectSpecs` definition of the project to be published to Behance
 @param delegate receive `id<AdobePublishProjectDelegate>` callbacks for project publishing events, such as completion, failure, and upload progress
 */
- (void)showProjectEditorWithSpecs:(AdobePublishProjectSpecs *)specs delegate:(id<AdobePublishProjectDelegate>)delegate;

/**
 Publish a work in progress to Behance. Presents in a modal view controller.
 
 @param specs `AdobePublishWIPSpecs` definition of the work in progress to be published to Behance
 @param delegate receive `id<AdobePublishWIPDelegate>` callbacks for work in progress publishing events, such as completion, failure, and upload progress
 */
- (void)showWorkInProgressEditorWithSpecs:(AdobePublishWIPSpecs *)specs delegate:(id<AdobePublishWIPDelegate>)delegate;

/**
 Presents the last project view controller again (ex. to display again in the case of a publishing error)
 
 @param delegate receive `id<AdobePublishProjectDelegate>` callbacks for project publishing events, such as completion, failure, and upload progress
 */
- (void)showLastProjectEditorWithDelegate:(id<AdobePublishProjectDelegate>)delegate;

/**
 Presents the last work in progress view controller again (ex. to display again in the case of a publishing error)
 
 @param delegate receive `id<AdobePublishWIPDelegate>` callbacks for work in progress publishing events, such as completion, failure, and upload progress
 */
- (void)showLastWorkInProgressEditorWithDelegate:(id<AdobePublishWIPDelegate>)delegate;

/**
 Remove an account previously stored by the user as their preferred account for an outside network (Facebook, Twitter)
 When a user first chooses to share their work to an outside network, they choose their preferred account on that network from all accounts they are signed into on the device settings.
 If only one account exists, that account is automatically stored as the preferred account.
 
 @param accountType The account type to remove the preferred account for
 */
- (void)removePreferredAccountWithType:(AdobePublishAccountType)accountType;

@end

/**
 allows clients to be notified of project publishing flow
 */
@protocol AdobePublishProjectDelegate <NSObject>
@optional

/**
 called when the project publishing flow is about to close
 */
- (void)projectPublishWillClose;

/**
 called when the project publishing flow has closed
 */
- (void)projectPublishDidClose;

/**
 called on project publishing upload progress for the project cover image
 
 @param bytesWritten number of bytes that were just uploaded
 @param totalBytesWritten total number of bytes that have been written so far
 @param totalBytesExpected total number of bytes of the cover image to be uploaded
 */
- (void)projectPublishCoverImageUploadBytesWritten:(NSUInteger)bytesWritten totalBytes:(long long)totalBytesWritten totalBytesExpected:(long long)totalBytesExpected;

/**
 called on project publishing upload progress for individual project images
 
 @param bytesWritten number of bytes that were just uploaded
 @param totalBytesWritten total number of bytes that have been written so far
 @param totalBytesExpected total number of bytes of the cover image to be uploaded
 @param imageNumber the image number written
 @param totalImages the total number of images
 */
- (void)projectPublishImageUploadBytesWritten:(NSUInteger)bytesWritten totalBytes:(long long)totalBytesWritten totalBytesExpected:(long long)totalBytesExpected
                                  imageNumber:(NSUInteger)imageNumber totalImages:(NSUInteger)totalImages;

/**
 called when project publishing has begun
 */
- (void)projectPublishDidStart;

/**
 called on project publishing success
 
 @param projectId the id of the project that was created
 */
- (void)projectPublishDidComplete:(NSNumber *)projectId;

/**
 called immediately after projectPublishDidComplete:
 allows delegates to override the default behavior of presenting a popup window upon publishing success
 
 @return delegates should return NO if they wish to prevent the popup window from being shown, default is YES
 */
- (BOOL)projectPublishShouldPresentSuccessPopup;

/**
 called if the end user taps "VIEW ON BEHANCE" in the success popup, indicating that they would like to view the published project
 if this method is not handled in the delegate, a webview will be presented displaying the project on behance.net
 
 @param projectId the id of the project that was created
 */
- (void)viewProjectTapped:(NSNumber *)projectId;

/**
 called on project publishing failure
 
 @param error the error that resulted in a failure
 */
- (void)projectPublishDidFail:(NSError *)error;

/**
 called if loading an existing project for editing fails
 
 @param error the error that resulted in a failure
 */
- (void)projectEditDidFail:(NSError *)error;

@end

/**
 allows clients to be notified of WIP publishing flow
 */
@protocol AdobePublishWIPDelegate <NSObject>
@optional

/**
 called when the work in progress publishing flow is about to close
 */
- (void)wipPublishWillClose;

/**
 called when the work in progress publishing flow has closed
 */
- (void)wipPublishDidClose;

/**
 called on work in progress publishing upload progress for the work in progress image
 
 @param bytesWritten number of bytes that were just uploaded
 @param totalBytesWritten total number of bytes that have been written so far
 @param totalBytesExpected total number of bytes of the image to be uploaded
 */
- (void)wipPublishImageUploadBytesWritten:(NSUInteger)bytesWritten totalBytes:(long long)totalBytesWritten totalBytesExpected:(long long)totalBytesExpected;

/**
 called on work in progress publishing upload has begun
 */
- (void)wipPublishDidStart;

/**
 called on work in progress publishing success
 
 @param wipId the id of the work in progress that was created
 @param revisionId the id of the revision if this was added as a revision to an existing work in progress
 */
- (void)wipPublishDidComplete:(NSNumber *)wipId revisionId:(NSNumber *)revisionId;

/**
 called immediately after wipPublishDidComplete:revisionId:
 allows delegates to override the default behavior of presenting a popup window upon publishing success
 
 @return delegates should return NO if they wish to prevent the popup window from being shown, default is YES
 */
- (BOOL)wipPublishShouldPresentSuccessPopup;

/**
 called if the end user taps "VIEW ON BEHANCE" in the success popup, indicating that they would like to view the published work in progress
 if this method is not handled in the delegate, a webview will be presented displaying the work in progress on behance.net
 
 @param wipId the id of the work in progress that was created
 @param revisionId the id of the work in progress revision that was created
 */
- (void)viewWorkInProgressTapped:(NSNumber *)wipId revisionId:(NSNumber *)revisionId;

/**
 called on work in progress publishing failure
 
 @param error the error that resulted in a failure
 */
- (void)wipPublishDidFail:(NSError *)error;

@end
