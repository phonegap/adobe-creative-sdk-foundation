//
//  AdobeKulerAuthor.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/29/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * To be documented
 */
@interface AdobeKulerAuthor : NSObject <NSCoding>
@property (unsafe_unretained, nonatomic) NSInteger authorId;
@property (copy, nonatomic) NSString* authorName;

-(NSDictionary*) dictionaryRepresentation;
+ (AdobeKulerAuthor *) objectFromDictionary:(NSDictionary *)dictResponse;
@end
