/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import "AdobeDeviceClipboardDelegate.h"
#import "AdobeDeviceInkContentViewControllerDelegate.h"

/**
 * Built-in Creative Cloud Clipboard View Controller.
 *
 * This View Controller is an out of the box Clipboard panel. It displays all clipboard content of the pen owner.
 */

@interface AdobeDeviceClipboardViewController : UIViewController<AdobeDeviceInkContentViewControllerDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UIAlertViewDelegate>

@property (nonatomic, weak) id<AdobeDeviceClipboardDelegate> clipboardDelegate;

@end
