//
//  AdobeKulerOwner.h
//  AdobeKuler
//
//  Created by Wally Ho on 12/10/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * To be documented
 */
@interface AdobeKulerOwner : NSObject <NSCoding>
@property (copy, nonatomic) NSString* ownerName;
@property (copy, nonatomic) NSString* ownerAdobeId;
@property (unsafe_unretained, nonatomic) NSInteger ownerVersion;

- (NSDictionary*) dictionaryRepresentation;

+ (AdobeKulerOwner *) objectFromDictionary:(NSDictionary *)dictResponse;

@end
