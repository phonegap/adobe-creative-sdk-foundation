/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <UIKit/UIKit.h>
#import "AdobeDeviceInkContentViewControllerDelegate.h"
#import "AdobeDeviceInkManager.h"
#import "AdobeKulerThemes.h"

@class AdobeDeviceKulerViewController;
@class AdobeDeviceClipboardViewController;
@class AdobeDeviceInkShareViewController;

@protocol AdobeDeviceInkMenuViewControllerDelegate;
@protocol AdobeDeviceInkMenuViewControllerKulerClipboardDelegate;


@interface AdobeDeviceInkMenuViewController : UIViewController


@property (strong, nonatomic) AdobeDeviceInkManager* deviceInkManager;

/**
 * This is the delegate to control the flow of the Ink Menu. 
 * If nil, the InkMenu will by default not show up.
 */
@property (nonatomic) id<AdobeDeviceInkMenuViewControllerDelegate> penInkMenuDelegate;

/** 
 Custom Node 1 visiblity property. By default it is YES
 */
@property (nonatomic, getter = isCustomNode1Hidden) BOOL customNode1Hidden;

/** 
 Custom Node 2 visiblity property. By default it is YES
 */
@property (nonatomic, getter = isCustomNode2Hidden) BOOL customNode2Hidden;

/** 
 Custom Node 3 visiblity property. By default it is YES
 */
@property (nonatomic, getter = isCustomNode3Hidden) BOOL customNode3Hidden;

/**
 Read-only access to Kuler View Controller
 */
@property (nonatomic, readonly) AdobeDeviceKulerViewController *kulerContentViewController;

/**
  Method to engage the asychronous call to see if the Pen and iPad are the same.
 */
-(void) kulerIsPenAndiPadOwnerTheSame;

/**
 Read-only access to Creative Cloud Clipboard View Controller
 */
@property (nonatomic,readonly) AdobeDeviceClipboardViewController *clipboardContentViewController;

/**
 Read-only access to Share View Controller
 */
@property (nonatomic,readonly) AdobeDeviceInkShareViewController *shareContentViewController;

/**
 First Custom Node View Controller.
 
 If set, the Pen Tip menu will use this view controller as content of the Popover of the given custom node button.
 This view controller must conform to AdobeDeviceInkContentViewControllerDelegate
 
 @see AdobeDeviceInkContentViewControllerDelegate
 */
@property (nonatomic) UIViewController<AdobeDeviceInkContentViewControllerDelegate> *customNode1ContentViewController;

/** 
 Second Custom Node View Controller.
 
 If set, the Pen Tip menu will use this view controller as content of the Popover of the given custom node button.
 This view controller must conform to AdobeDeviceInkContentViewControllerDelegate
 
 @see AdobeDeviceInkContentViewControllerDelegate
 */
@property (nonatomic) UIViewController<AdobeDeviceInkContentViewControllerDelegate> *customNode2ContentViewController;

/** 
 Third Custom Node View Controller.
 
 If set, the Pen Tip menu will use this view controller as content of the Popover of the given custom node button.
 This view controller must conform to AdobeDeviceInkContentViewControllerDelegate
 
 @see AdobeDeviceInkContentViewControllerDelegate
 */
@property (nonatomic) UIViewController<AdobeDeviceInkContentViewControllerDelegate> *customNode3ContentViewController;

/**
 Clients may customize the popover background chrome of the Nodes by providing a class which subclasses `UIPopoverBackgroundView` 
 and which implements the required instance and class methods on that class.
 */
@property (nonatomic, readwrite, retain) Class popoverBackgroundViewClass;

@end


/**
 * This is the definition of the delegate that control the flow of the Ink Menu.
 */
@protocol AdobeDeviceInkMenuViewControllerDelegate <NSObject>
@required

/**
 * When the Ink Menu is invoked this delegate method is called.
 *
 * @return YES to present the InkMenu or NO to cancel.
 */
- (BOOL)shouldPresentInkMenu;

/**
 * If the Ink Menu should be presented then this delegate method is called in order to know in 
 * which UIView the InkMenu appears.
 *
 * @return a reference to the UIViewController in which the Ink Menu must be displayed.
 */
- (UIViewController*)willPresentInViewController;

@optional

/**
 * If an action in the Ink Menu share sheet is chosen, and array of AdobeDeviceShareItem objects to share will
 * be requested with this delegate method.
 * 
 * @return an array of AdobeDeviceShareItem objects for sharing.
 */

- (NSArray *)itemsToShareFromInkMenu;

@end

@protocol AdobeDeviceInkMenuViewControllerKulerClipboardDelegate <NSObject>
@optional
- (void) kulerPersistCreativeCloudThemes:(AdobeKulerThemes*) themes;
- (void) kulerRemoveCreativeCloudThemes;
- (BOOL) kulerRetrieveCreativeCloudThemesAndSetKulerComponent;
@end

