//
//  AdobeKulerTheme.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/29/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AdobeKulerHarmony.h"
#import "AdobeKulerTag.h"
#import "AdobeKulerSwatches.h"
#import "AdobeKulerRating.h"
#import "AdobeKulerAuthor.h"
#import "AdobeKulerComment.h"
#import "AdobeKulerOwner.h"


/**
 * To be documented
 */
@interface AdobeKulerTheme : NSObject <NSCoding>

@property (unsafe_unretained, nonatomic) BOOL canBeDeleted;
@property (unsafe_unretained, nonatomic) BOOL isChecked;
@property (unsafe_unretained, nonatomic) NSInteger themeId;
@property (strong, nonatomic) AdobeKulerHarmony* harmony;
@property (strong, nonatomic) AdobeKulerTag* tag;
@property (strong, nonatomic) AdobeKulerSwatches* swatches;
@property (strong, nonatomic) AdobeKulerRating* rating;  // overall integer and user
@property (strong, nonatomic) AdobeKulerAuthor* author;  // id integer and namestring
@property (strong, nonatomic) AdobeKulerComment* comment;
@property (copy,   nonatomic) NSString* name;
@property (unsafe_unretained, nonatomic) NSInteger likeCount;
@property (unsafe_unretained, nonatomic) NSInteger viewCount;

@property (strong, nonatomic) NSDate* editedAt;
@property (strong, nonatomic) NSDate* createdAt;


-(NSDictionary*) dictionaryRepresentation;
+ (AdobeKulerTheme *) objectFromDictionary:(NSDictionary *)dictResponse;
+ (NSDate*) dateFromDateString:(NSString*) dateString;
@end
