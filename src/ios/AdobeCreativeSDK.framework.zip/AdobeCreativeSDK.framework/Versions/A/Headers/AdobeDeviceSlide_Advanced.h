/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import "AdobeDeviceSlide.h"
#import "AdobeDeviceSlideView.h"
#import "AdobeDeviceSlideShape.h"
#import "AdobeDeviceSlideShape_AdvancedSnapping.h"
#import "AdobeDeviceSlidePackSwitcherViewController.h"

@interface AdobeDeviceSlide ()

@property (nonatomic, weak) id<AdobeDeviceSlidePerspectiveDelegate> perspectiveDelegate;
@property (nonatomic, weak) id<AdobeDeviceSlideShapeDelegate> snapDelegate;

@property (readonly, nonatomic) AdobeDeviceSlideView *slideView;
@property (readonly, nonatomic) AdobeDeviceSlidePackSwitcherViewController *slidePackSwitcherViewController;

@property (nonatomic) BOOL perspectiveSnappingOn;

- (void)showSlideView:(BOOL)show;

- (void)addSlidePacksFromPlistAtPath:(NSString *)path
             withFilesInSourceBundle:(NSBundle *)bundle;

- (NSArray *)pointsSnappedToCurrentTracePath;
- (NSArray *)intersectionPointsForCurrentTracePath;

- (void)snapToLeftVanishingPoint:(CGPoint)leftVP
             rightVanishingPoint:(CGPoint)rightVP
                          inView:(UIView *)view;

@end
