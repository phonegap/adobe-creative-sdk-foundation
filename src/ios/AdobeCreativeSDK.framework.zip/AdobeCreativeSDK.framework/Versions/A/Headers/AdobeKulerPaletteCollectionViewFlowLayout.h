//
//  AdobeKulerPaletteCollectionViewFlowLayout.h
//  AdobeKuler
//
//  Created by Wally Ho on 10/25/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

/**
 * To be documented
 */

#import <UIKit/UIKit.h>
@interface AdobeKulerPaletteCollectionViewFlowLayout : UICollectionViewFlowLayout

@end
