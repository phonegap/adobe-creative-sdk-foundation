/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

// Reviewed by rhorns on October 8, 2013

#import <Foundation/Foundation.h>

/** The domain for Adobe Storage errors */
extern NSString *const AdobeStorageErrorDomain;

/** These keys may appear in the NSError userInfo dictionary for errors
 in the AdobeStorageErrorDomain. */

extern NSString *const AdobeStorageRequestURLStringKey; /**< userInfo key returning an NSString* containing 
                                                         the url of the request that caused the error. */
extern NSString *const AdobeStoragePathKey;             /**< userInfo key returning an NSString* containing 
                                                         the path of a local file that caused the error. */
extern NSString *const AdobeStorageResponseHeadersKey;  /**< userInfo key returning an NSDictionary* 
                                                         containing the repsonse headers of the request 
                                                         that caused the error. */
extern NSString *const AdobeStorageResponseDataKey;     /**< userInfo key returning an NSData* containing 
                                                         the data returned from the request that caused 
                                                         the error. */
extern NSString *const AdobeNetworkHTTPStatusKey;       /**< userInfo key returning an NSNumber containing 
                                                         the HTTP status code returned by the request 
                                                         that caused the error. */
extern NSString *const AdobeStorageOtherErrorsKey;      /**< userInfo key returning an NSArray containing 
                                                         other errors that happened in parallel. */
extern NSString *const AdobeStorageDetailsStringKey;    /**< userInfo key returning an NSString. containing 
                                                         a clear text description of the problem. */


/**
 Error codes for the storage error domain.
 */
typedef NS_ENUM(NSInteger, AdobeStorageErrorCode) {
    
    /**
     The request cannot be completed.
     
     This typically means that there is something wrong with the url, the data,
     or the file system. Repeating the request will most likely not help.
     
     The userInfo property of the error often contains additional information via
     the AdobeStorageRequestURLKey, AdobeStorageResponseDataKey, AdobeNetworkHTTPStatusKey, AdobeStorageResponseHeadersKey
     and NSUnderlyingErrorKey keys.
     */
    AdobeStorageErrorBadRequest = 0,
    
    /**
     This error indicates a (likely temporary) problem with the network. This could
     be caused by a server that is down or just too slow to respond.
     
     The NSUnderlyingErrorKey entry in userInfo often contains more information about the
     cause of this error.
     */
    AdobeStorageErrorNetworkFailure = 1,
    
    /**
     A response from the server did not match its anticipated form and therefore
     could not be processed.
     
     This could be caused by an unexpected HTTP response code or missing/malformed data.
     Typically this indicates a (temporary) problem with the server or the network.
     
     The userInfo property of the error often contains additional information via
     the AdobeStorageRequestURLKey, AdobeStorageResponseDataKey, AdobeNetworkHTTPStatusKey, AdobeStorageResponseHeadersKey
     and NSUnderlyingErrorKey keys.
     */
    AdobeStorageErrorUnexpectedResponse = 2,
    
    /**
     This error indicates that the device doesn't have a network connection (any more).
     
     The NSUnderlyingErrorKey entry in userInfo often contains more information about the
     cause of this error.
     */
    AdobeStorageErrorOffline = 3,
    
    /**
     This error indicates that the operation was cancelled.
     
     The NSUnderlyingErrorKey entry in userInfo often contains more information about the
     cause of this error.
     */
    AdobeStorageErrorCancelled = 4,
    
    /**
     The request failed due to an authentication failure, such as missing or
     incorrect credentials.
     */
    AdobeStorageErrorAuthenticationFailed = 5,
    
    /**
     The service is disconnected. This most likely happened because too many requests
     have failed.
     */
    AdobeStorageErrorServiceDisconnected = 6,
    
    /**
     Both the local copy and the copy on the server have been modified.
     
     This error can happen when trying to push local changes to an asset on the
     server.
     */
    AdobeStorageErrorConflictingChanges = 7,
    
    /**
     Reading from a file has failed.
     
     This error can happen when a file fails to upload because it can't be found or read.
     */
    AdobeStorageErrorFileReadFailure = 8,
    
    /**
     Writing to a file has failed.
     
     This error can happen when a file fails to download because it can't be written to local storage.
     */
    AdobeStorageErrorFileWriteFailure = 9,
    
    /**
     An upload has failed because it would have exceeded the quota on the account
     */
    AdobeStorageErrorExceededQuota = 10,
    
    /**
     An attempt was made to use an empty JSON payload.
     */
    AdobeStorageMissingJSONData = 11
};