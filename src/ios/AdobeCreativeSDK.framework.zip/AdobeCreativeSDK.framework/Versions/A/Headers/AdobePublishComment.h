/******************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of
 * Adobe Systems Incorporated and its suppliers, if any. The intellectual and
 * technical concepts contained herein are proprietary to Adobe Systems
 * Incorporated and its suppliers and are protected by trade secret or
 * copyright law. Dissemination of this information or reproduction of this
 * material is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/

#import <Foundation/Foundation.h>
#import "AdobePublishBaseModel.h"
#import "AdobePublishUser.h"

/**
 `AdobePublishComment` represents a user comment on Behance.net.
 */
@interface AdobePublishComment : AdobePublishBaseModel

/**
 The comment id for the comment
 */
@property (nonatomic, strong) NSNumber * commentId;

/**
 The comment body for the comment
 */
@property (nonatomic, strong) NSString * body;

/**
 The creation timestamp for the comment
 */
@property (nonatomic, strong) NSDate * timestamp;

/**
 The user id of the user who created the comment
 */
@property (nonatomic, strong) NSNumber * userId;

/**
 The username of the user who created the comment
 */
@property (nonatomic, strong) NSString * username;

/**
 The avatar image url of the user who created the comment
 */
@property (nonatomic, strong) NSURL * userImageUrl;

@end
