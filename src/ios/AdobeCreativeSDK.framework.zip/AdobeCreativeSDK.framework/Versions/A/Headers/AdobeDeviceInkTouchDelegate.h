/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

@protocol AdobeDeviceInkTouchDelegate <NSObject>

/** 
 * Sets the initial touches of a pen.
 * @param touches Sets of initial touches where pen begins touching
 */
- (void)penTouchBegan:(NSSet*)touches;

/**
 * Sets the movement of touches of a pen.
 * @param touches Sets of touches where pen is moving
 */
- (void)penTouchMoved:(NSSet*)touches;

/** 
 * Sets the end touches of a pen.
 * @param touches Sets of touches where pen ends
 */
- (void)penTouchEnded:(NSSet*)touches;

/** 
 * Sets cancelled touches of a pen.
 * @param touches Sets of touches where pen cancels
 */
- (void)penTouchCancelled:(NSSet*)touches;

/** 
 * Suggest to disable gestures when the pen is down to prevent conflict.
 */
- (void)penSuggestsToDisableGestures;

/**
 * Suggest to enable gestures when the pen is not down as there are no potential conflicts.
 */
- (void)penSuggestsToEnableGestures;

@end
