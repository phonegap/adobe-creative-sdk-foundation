//
//  AdobeKulerPaletteTableViewCell.h
//  AdobeKuler
//
//  Created by Wally Ho on 12/5/13.
//  Copyright (c) 2013 Adobe Systems. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol AdobeKulerPaletteTableViewCellDelegate;


/**
 * To be documented
 */
@interface AdobeKulerPaletteTableViewCell : UITableViewCell
<
UIScrollViewDelegate,
UIGestureRecognizerDelegate
>

@property (weak, nonatomic) IBOutlet UIView *viewContainingChoiceUnderColors;
@property (weak, nonatomic) IBOutlet UIView *viewContainingSqueezableViews;
@property (weak, nonatomic) IBOutlet UIView *viewSwatch1;
@property (weak, nonatomic) IBOutlet UIView *viewSwatch2;
@property (weak, nonatomic) IBOutlet UIView *viewSwatch3;
@property (weak, nonatomic) IBOutlet UIView *viewSwatch4;
@property (weak, nonatomic) IBOutlet UIView *viewSwatch5;


@property (weak, nonatomic) IBOutlet UIButton *buttonDeleteTheme;
@property (weak, nonatomic) IBOutlet UILabel *labelThemeName;
@property (weak, nonatomic) IBOutlet UILabel *labelThemeCreatedBy;

@property (weak, nonatomic) id<AdobeKulerPaletteTableViewCellDelegate>  delegateKulerPaletteTableViewCell;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraintView1Width;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraintViewContainingColorsTrailingSpace;


@end



@protocol AdobeKulerPaletteTableViewCellDelegate <NSObject>

@optional
- (void) scrollingCellViewDidBeginScrolling:(AdobeKulerPaletteTableViewCell*) cell;
- (void) scrollingCellView:(AdobeKulerPaletteTableViewCell*) cell didChangePullOffset:(CGFloat) offset;
- (void) scrollingCellViewDidEndScrolling:(AdobeKulerPaletteTableViewCell*) cell;
//These are to allow the main view to know the cell opening activates the re-order
-(void) scrollingCellDidOpen:(AdobeKulerPaletteTableViewCell*) cell;
-(void) scrollingCellDidClose:(AdobeKulerPaletteTableViewCell*) cell;


- (void) buttonThemeDelete:(AdobeKulerPaletteTableViewCell*) cell sender:(id) sender;
@end
