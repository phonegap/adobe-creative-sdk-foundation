/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 **************************************************************************/

#import <Foundation/Foundation.h>

#import "AdobeDeviceVectorPath.h"

/**
 * An AdobeDeviceVectorShape is a collection of AdobeDeviceVectorPaths which, together, represent a single shape.
 * The component vector paths are not necessarily connected or contiguous in any way.
 */

@interface AdobeDeviceVectorShape : NSObject

/**
 The array of AdobeDeviceVectorPath objects comprising the shape
 */
@property (nonatomic, readonly) NSArray *paths;

/**
 Convenience constructor for instantiating a new shape with a given array of paths.
 
 @param paths An array of AdobeDeviceVectorPath objects from which to construct the shape.
 @return An AdobeDeviceVectorShape object, constructed from the input paths.
 */
+ (AdobeDeviceVectorShape *)shapeWithPaths:(NSArray *)paths;

@end
