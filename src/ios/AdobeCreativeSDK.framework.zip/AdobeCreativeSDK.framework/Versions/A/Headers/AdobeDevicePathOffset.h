//
//  AdobeDevicePathOffset.h
//  Device
//
//  Created by Greg on 2/4/14.
//  Copyright (c) 2014 Adobe. All rights reserved.
//

/**
 * An AdobeDevicePathOffset represents a parametric location along an AdobeDeviceVectorPath.
 * The segmentIndex is the index of the AdobeDeviceVectorSegment in the path's segments array on which the path offset is located.
 * The t value is the parametric location along the segment (ranging from 0 to 1) at which the path offset is located.
 */
struct AdobeDevicePathOffset {
    NSUInteger segmentIndex;
    CGFloat t;
};
typedef struct AdobeDevicePathOffset AdobeDevicePathOffset;

/**
 Returns a path offset with the designated segment index and t value
 
 @param segmentIndex The index of the segment along the path on which the path offset is located
 @param t The parametric t value (ranging from 0 to 1 on a segment) at which the path offset is located
 */
AdobeDevicePathOffset AdobeDevicePathOffsetMake(const NSUInteger segmentIndex, const CGFloat t);
